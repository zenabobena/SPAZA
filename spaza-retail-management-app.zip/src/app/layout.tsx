import type { Metadata, Viewport } from "next";
import { Anton, Archivo } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const anton = Anton({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-anton",
  display: "swap",
});

const archivo = Archivo({
  subsets: ["latin"],
  variable: "--font-archivo",
  display: "swap",
});

export const metadata: Metadata = {
  title: "SPAZA — Run Your Shop Like a Boss",
  description:
    "Offline-first business OS for South African spaza shops: smart inventory & pricing, wholesale price matrix, delivery float planner, customer tab book, break-even dashboard, VAS ledger and a compliance hub.",
  applicationName: "SPAZA",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/icon-512.png", apple: "/icon-512.png" },
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "SPAZA",
  },
};

export const viewport: Viewport = {
  themeColor: "#17130b",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${anton.variable} ${archivo.variable}`}>
      <body className="bg-paper font-sans text-ink antialiased">
        {children}
      </body>
    </html>
  );
}
