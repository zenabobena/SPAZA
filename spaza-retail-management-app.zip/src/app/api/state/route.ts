/* ------------------------------------------------------------------ */
/* SPAZA — /api/state                                                   */
/* GET  → full shop state (seeds the DB on first run)                   */
/* PUT  → snapshot replace of the whole shop state (single transaction) */
/* Sync strategy: last-writer-wins via updatedAt (single owner device). */
/* ------------------------------------------------------------------ */

import { db } from "@/db";
import {
  complianceChecks,
  creditEntries,
  customers,
  deliveryLines,
  expenses,
  products,
  shopMeta,
  vasTxns,
  wholesalerPrices,
} from "@/db/schema";
import { seedState } from "@/lib/seed";
import type { AppState, ExpenseCategory, VasType } from "@/lib/types";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const META_ID = "shop";

async function writeSnapshot(state: AppState) {
  await db.transaction(async (tx) => {
    await tx.delete(creditEntries);
    await tx.delete(deliveryLines);
    await tx.delete(wholesalerPrices);
    await tx.delete(customers);
    await tx.delete(expenses);
    await tx.delete(vasTxns);
    await tx.delete(products);
    await tx.delete(complianceChecks);
    await tx.delete(shopMeta);

    if (state.products.length) await tx.insert(products).values(state.products);
    if (state.wholesalers.length)
      await tx.insert(wholesalerPrices).values(state.wholesalers);
    if (state.deliveries.length)
      await tx.insert(deliveryLines).values(state.deliveries);
    if (state.customers.length) await tx.insert(customers).values(state.customers);
    if (state.creditEntries.length)
      await tx.insert(creditEntries).values(state.creditEntries);
    if (state.expenses.length) await tx.insert(expenses).values(state.expenses);
    if (state.vasTxns.length) await tx.insert(vasTxns).values(state.vasTxns);

    const checks = Object.entries(state.compliance)
      .filter(([, done]) => done)
      .map(([id]) => ({ id, done: true }));
    if (checks.length) await tx.insert(complianceChecks).values(checks);

    await tx.insert(shopMeta).values({ id: META_ID, updatedAt: state.updatedAt });
  });
}

async function readSnapshot(): Promise<AppState | null> {
  const [meta] = await db.select().from(shopMeta).limit(1);
  if (!meta) return null;

  const [
    prows,
    wrows,
    drows,
    crows,
    erows,
    xrows,
    vrows,
    checklist,
  ] = await Promise.all([
    db.select().from(products),
    db.select().from(wholesalerPrices),
    db.select().from(deliveryLines),
    db.select().from(customers),
    db.select().from(creditEntries),
    db.select().from(expenses),
    db.select().from(vasTxns),
    db.select().from(complianceChecks),
  ]);

  const compliance: Record<string, boolean> = {};
  for (const c of checklist) compliance[c.id] = c.done;

  return {
    updatedAt: meta.updatedAt,
    products: prows,
    wholesalers: wrows,
    deliveries: drows,
    customers: crows,
    creditEntries: erows,
    expenses: xrows.map((x) => ({
      ...x,
      category: x.category as ExpenseCategory,
    })),
    vasTxns: vrows.map((v) => ({ ...v, type: v.type as VasType, reference: v.reference ?? undefined })),
    compliance,
  };
}

export async function GET() {
  try {
    let state = await readSnapshot();
    if (!state) {
      state = seedState();
      await writeSnapshot(state);
    }
    return NextResponse.json(state);
  } catch (err) {
    console.error("[/api/state GET]", err);
    return NextResponse.json(
      { error: "Failed to load shop state" },
      { status: 500 }
    );
  }
}

export async function PUT(req: Request) {
  try {
    const body = (await req.json()) as Partial<AppState>;
    if (!body || !Array.isArray(body.products)) {
      return NextResponse.json({ error: "Invalid state payload" }, { status: 400 });
    }
    const state: AppState = {
      products: body.products ?? [],
      wholesalers: body.wholesalers ?? [],
      deliveries: body.deliveries ?? [],
      customers: body.customers ?? [],
      creditEntries: body.creditEntries ?? [],
      expenses: body.expenses ?? [],
      vasTxns: body.vasTxns ?? [],
      compliance: body.compliance ?? {},
      updatedAt: new Date().toISOString(),
    };
    await writeSnapshot(state);
    return NextResponse.json({ ok: true, updatedAt: state.updatedAt });
  } catch (err) {
    console.error("[/api/state PUT]", err);
    return NextResponse.json(
      { error: "Failed to save shop state" },
      { status: 500 }
    );
  }
}
