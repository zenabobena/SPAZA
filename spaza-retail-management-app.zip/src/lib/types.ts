/* ------------------------------------------------------------------ */
/* SPAZA — shared domain types (client + server)                       */
/* ------------------------------------------------------------------ */

export type ID = string;

/** Module A — Smart Inventory Master List */
export interface Product {
  id: ID;
  name: string;
  category: string;
  /** Wholesale cost price (R) — piped in from the Wholesale Matrix (Module B) */
  costPrice: number;
  /** Target gross profit margin (%) */
  marginPct: number;
  /** Manual final selling price override (R). null → auto from margin engine */
  overridePrice: number | null;
  stock: number;
  reorderLevel: number;
  supplier: string;
}

/** Module B — Wholesale Price Comparison Matrix row (linked to a product) */
export interface WholesalerRow {
  id: ID;
  productId: ID;
  costA: number | null;
  costB: number | null;
  costC: number | null;
  /** When true, MIN(A,B,C) is auto-piped into the product's cost price */
  autoSync: boolean;
}

/** Module C — Cash Flow & Delivery Float line */
export interface DeliveryLine {
  id: ID;
  productId: ID;
  qtyPerDay: number;
  daysPerWeek: number;
}

/** Module D — Customer Credit Book ("Tab") */
export interface Customer {
  id: ID;
  name: string;
  phone: string;
  creditLimit: number; // R
}

export interface CreditEntry {
  id: ID;
  customerId: ID;
  date: string; // ISO yyyy-mm-dd
  item: string; // item / reason
  /** Money the customer took on tab (R) */
  credit: number;
  /** Money the customer paid back (R) */
  payment: number;
}

/** Module E — Overheads (recurring monthly fixed costs) */
export type ExpenseCategory =
  | "Rent"
  | "Electricity"
  | "Transport"
  | "Data"
  | "Other";

export interface Expense {
  id: ID;
  category: ExpenseCategory;
  label: string;
  /** Recurring monthly amount (R) */
  amount: number;
}

/** Module F — Value-Added Services ledger (digital vending) */
export type VasType = "electricity" | "airtime" | "bills";

export interface VasTxn {
  id: ID;
  date: string; // ISO yyyy-mm-dd
  type: VasType;
  /** Vend value sold to customer (R) */
  amount: number;
  /** Vendor commission rate (%) */
  commissionPct: number;
  reference?: string;
}

/** Whole-shop state document (synced between device + server) */
export interface AppState {
  products: Product[];
  wholesalers: WholesalerRow[];
  deliveries: DeliveryLine[];
  customers: Customer[];
  creditEntries: CreditEntry[];
  expenses: Expense[];
  vasTxns: VasTxn[];
  /** Compliance Hub progress: stepId → done */
  compliance: Record<string, boolean>;
  updatedAt: string; // ISO timestamp, last-writer-wins sync
}

export type CollectionKey =
  | "products"
  | "wholesalers"
  | "deliveries"
  | "customers"
  | "creditEntries"
  | "expenses"
  | "vasTxns";

export const WHOLESALERS = ["Makro", "Boxer Superstore", "Jumbo Cash"] as const;

export const VAS_META: Record<
  VasType,
  { label: string; defaultPct: number; blurb: string }
> = {
  electricity: {
    label: "Prepaid Electricity",
    defaultPct: 2.5,
    blurb: "Eskom / municipal tokens",
  },
  airtime: {
    label: "Airtime & Data",
    defaultPct: 5,
    blurb: "Vodacom · MTN · Telkom · Cell C",
  },
  bills: {
    label: "DSTV & Bill Payments",
    defaultPct: 2,
    blurb: "DSTV · utilities · TV licences",
  },
};

export const EXPENSE_CATEGORIES: {
  value: ExpenseCategory;
  label: string;
  hint: string;
}[] = [
  { value: "Rent", label: "Space Rental", hint: "Shop rent & yard fees" },
  { value: "Electricity", label: "Electricity Tokens", hint: "Commercial prepaid" },
  { value: "Transport", label: "Transport / Petrol", hint: "Buying trips, bakkie" },
  { value: "Data", label: "Mobile Data", hint: "Card machine + phone data" },
  { value: "Other", label: "Other", hint: "Security, licences, misc" },
];

/* ---------------- Compliance Hub content ---------------- */

export interface ComplianceStep {
  id: string;
  title: string;
  detail: string;
}

export interface ComplianceSection {
  id: string;
  code: string;
  title: string;
  authority: string;
  summary: string;
  steps: ComplianceStep[];
}

export const COMPLIANCE_SECTIONS: ComplianceSection[] = [
  {
    id: "cipc",
    code: "01",
    title: "CIPC Registration",
    authority: "Companies & Intellectual Property Commission",
    summary:
      "Get your business onto the official register so you can open bank accounts, lease premises and tender for supplier terms.",
    steps: [
      {
        id: "cipc.1",
        title: "Reserve your business name",
        detail:
          "Lodige a name reservation on CIPC eServices (eservices.cipc.co.za). Keep 2–3 backup names ready.",
      },
      {
        id: "cipc.2",
        title: "Register the business",
        detail:
          "File a private company (Pty Ltd) on CIPC eServices / BizPortal — or trade as a sole proprietor and record it here.",
      },
      {
        id: "cipc.3",
        title: "File your registration certificate",
        detail:
          "Save your CoR14.3 registration certificate + tracking number. Note your enterprise number in the shop records book.",
      },
      {
        id: "cipc.4",
        title: "Diarise the annual return",
        detail:
          "CIPC annual returns keep your registration active. Set a yearly reminder so the business is never deregistered.",
      },
    ],
  },
  {
    id: "sars",
    code: "02",
    title: "SARS Tax Profile",
    authority: "South African Revenue Service",
    summary:
      "A clean tax profile protects your shop, unlocks supplier accounts, and keeps penalties away from your till money.",
    steps: [
      {
        id: "sars.1",
        title: "Create your eFiling profile",
        detail:
          "Register at sarsefiling.co.za with your ID. Link the business once its tax number is issued.",
      },
      {
        id: "sars.2",
        title: "Get the Income Tax reference number",
        detail:
          "CIPC registrations are auto-registered for income tax — confirm the number on eFiling or at a SARS branch.",
      },
      {
        id: "sars.3",
        title: "Decide on Turnover Tax (micro business)",
        detail:
          "If turnover is under R1m/year you may qualify for simplified Turnover Tax — cheaper and less admin than full company tax.",
      },
      {
        id: "sars.4",
        title: "Check VAT registration status",
        detail:
          "Compulsory VAT registration kicks in above R1m turnover in any 12 months. Voluntary registration is possible from R50 000.",
      },
    ],
  },
  {
    id: "muni",
    code: "03",
    title: "Trading Permit & Zoning",
    authority: "Your Local Municipality",
    summary:
      "Trading without a permit risks fines and stock confiscation. Confirm the land use first, then license the trade.",
    steps: [
      {
        id: "muni.1",
        title: "Verify land use / zoning consent",
        detail:
          "Ask the municipal planning office to confirm the property may be used for retail trading (or apply for consent use).",
      },
      {
        id: "muni.2",
        title: "Apply for a Business Trading permit",
        detail:
          "Submit ID, lease/landlord consent letter and zoning confirmation to the licensing department. Keep the receipt copy.",
      },
      {
        id: "muni.3",
        title: "Collect and display the permit",
        detail:
          "Pin the approved permit near the entrance where inspectors and customers can see it.",
      },
      {
        id: "muni.4",
        title: "Renew every year",
        detail:
          "Trading permits lapse. Diarise the renewal month and budget the renewal fee in your overheads.",
      },
    ],
  },
  {
    id: "coa",
    code: "04",
    title: "Certificate of Acceptability (R638)",
    authority: "Department of Health · Environmental Health",
    summary:
      "Anyone handling food must hold a COA under Regulation R638. It covers hygiene, food safety and cold-chain discipline.",
    steps: [
      {
        id: "coa.1",
        title: "Apply to the Environmental Health Practitioner",
        detail:
          "Request a COA inspection via your municipal Environmental Health office (R638 food premises registration).",
      },
      {
        id: "coa.2",
        title: "Sanitation & handwashing access",
        detail:
          "Provide a handwash basin with soap, clean water supply and access to a toilet for anyone handling food.",
      },
      {
        id: "coa.3",
        title: "Separate chemicals from food",
        detail:
          "Move doom, jik, paraffin and detergents to their own shelf or cupboard — never above or beside food stock.",
      },
      {
        id: "coa.4",
        title: "Cold chain: fridges below 4°C",
        detail:
          "Fit a thermometer in every fridge. Check and log temperatures morning and evening — always below 4°C.",
      },
      {
        id: "coa.5",
        title: "Pass inspection & display the COA",
        detail:
          "Once issued, display the Certificate of Acceptability next to your trading permit and keep it current.",
      },
    ],
  },
];
