/* ------------------------------------------------------------------ */
/* SPAZA — calculation engine (pure functions, fully testable)         */
/* Every interlinked formula in the app lives here.                    */
/* ------------------------------------------------------------------ */

import { r2 } from "./money";
import type {
  CreditEntry,
  Customer,
  DeliveryLine,
  Expense,
  Product,
  VasTxn,
  VasType,
  WholesalerRow,
} from "./types";
import { WHOLESALERS, VAS_META } from "./types";

/* ============ Module A — Pricing Engine ============ */

/**
 * Retail price from target gross profit margin:
 *   Margin% = (Sell − Cost) / Sell   →   Sell = Cost / (1 − Margin%)
 */
export function retailFromMargin(cost: number, marginPct: number): number {
  const m = marginPct / 100;
  if (m >= 0.95 || cost <= 0) return r2(cost);
  return r2(cost / (1 - m));
}

/** The price the customer actually pays (manual override wins). */
export function sellingPrice(p: Product): number {
  return p.overridePrice && p.overridePrice > 0
    ? r2(p.overridePrice)
    : retailFromMargin(p.costPrice, p.marginPct);
}

/** Effective gross margin (%) at the active selling price. */
export function effectiveMarginPct(p: Product): number {
  const sell = sellingPrice(p);
  if (sell <= 0) return 0;
  return r2(((sell - p.costPrice) / sell) * 100);
}

/** Rand gross profit per unit at the active selling price. */
export function gpPerUnit(p: Product): number {
  return r2(sellingPrice(p) - p.costPrice);
}

/** Reorder alert: stock at or below the minimum reorder level. */
export function isReorder(p: Product): boolean {
  return p.stock <= p.reorderLevel;
}

export function stockValueAtCost(products: Product[]): number {
  return r2(products.reduce((s, p) => s + p.costPrice * Math.max(0, p.stock), 0));
}

export function stockValueAtRetail(products: Product[]): number {
  return r2(products.reduce((s, p) => s + sellingPrice(p) * Math.max(0, p.stock), 0));
}

/**
 * Shop-wide weighted average gross margin (%).
 * Weighted by rand value of stock at cost — the money actually invested
 * in each line — so big movers pull the average, not dead stock.
 */
export function weightedAvgMargin(products: Product[]): {
  pct: number;
  basis: "weighted" | "simple" | "default";
} {
  const live = products.filter((p) => p.stock > 0 && sellingPrice(p) > 0);
  if (live.length === 0) {
    if (products.length > 0) {
      const simple =
        products.reduce((s, p) => s + effectiveMarginPct(p), 0) / products.length;
      return { pct: r2(simple), basis: "simple" };
    }
    return { pct: 25, basis: "default" };
  }
  let wSum = 0;
  let wTotal = 0;
  for (const p of live) {
    const w = p.costPrice * p.stock;
    wSum += effectiveMarginPct(p) * w;
    wTotal += w;
  }
  return { pct: wTotal > 0 ? r2(wSum / wTotal) : 25, basis: "weighted" };
}

/* ============ Module B — Wholesale Comparison Matrix ============ */

export interface BestPrice {
  value: number;
  /** Index into WHOLESALERS (0 = A, 1 = B, 2 = C) */
  source: number;
}

/** MIN() across the three wholesalers for one product. */
export function bestWholesalePrice(row: WholesalerRow): BestPrice | null {
  const cells: [number, number | null][] = [
    [0, row.costA],
    [1, row.costB],
    [2, row.costC],
  ];
  let best: BestPrice | null = null;
  for (const [source, v] of cells) {
    if (v != null && v > 0 && (best === null || v < best.value)) {
      best = { value: r2(v), source };
    }
  }
  return best;
}

export function wholesalerName(idx: number): string {
  return WHOLESALERS[idx] ?? `Wholesaler ${idx + 1}`;
}

/* ============ Module C — Delivery Float Estimator ============ */

export interface FloatLine {
  line: DeliveryLine;
  product: Product | undefined;
  unitCost: number;
  weeklyUnits: number;
  weeklyCost: number;
}

export function floatReport(
  lines: DeliveryLine[],
  products: Product[]
): { lines: FloatLine[]; totalWeekly: number } {
  const out: FloatLine[] = lines.map((line) => {
    const product = products.find((p) => p.id === line.productId);
    const unitCost = product ? product.costPrice : 0;
    const weeklyUnits = line.qtyPerDay * line.daysPerWeek;
    return {
      line,
      product,
      unitCost,
      weeklyUnits,
      weeklyCost: r2(weeklyUnits * unitCost),
    };
  });
  return {
    lines: out,
    totalWeekly: r2(out.reduce((s, l) => s + l.weeklyCost, 0)),
  };
}

/* ============ Module D — Credit Book ("Tab") ============ */

export interface CustomerTotals {
  credit: number;
  paid: number;
  balance: number;
}

export function customerTotals(
  customerId: string,
  entries: CreditEntry[]
): CustomerTotals {
  let credit = 0;
  let paid = 0;
  for (const e of entries) {
    if (e.customerId !== customerId) continue;
    credit += e.credit;
    paid += e.payment;
  }
  return { credit: r2(credit), paid: r2(paid), balance: r2(credit - paid) };
}

export type TabStatus = "clear" | "good" | "near" | "breached";

/**
 * Guardrail: outstanding > limit  →  "CREDIT LIMIT BREACHED"
 * and no further tab entries may be issued until money comes back.
 */
export function tabStatus(customer: Customer, balance: number): TabStatus {
  if (balance > customer.creditLimit + 0.004) return "breached";
  if (balance <= 0.004) return "clear";
  if (balance >= customer.creditLimit * 0.8) return "near";
  return "good";
}

/** May the till write a new tab entry of `amount` right now? */
export function canIssueCredit(
  customer: Customer,
  balance: number,
  amount: number
): { ok: boolean; reason: string | null } {
  const status = tabStatus(customer, balance);
  if (status === "breached") {
    return {
      ok: false,
      reason:
        "Credit limit breached — a repayment must land before new tabs are opened.",
    };
  }
  if (amount > 0 && balance + amount > customer.creditLimit + 0.004) {
    return {
      ok: false,
      reason: `This would push the tab past the limit.`,
    };
  }
  return { ok: true, reason: null };
}

export function creditSummary(
  customers: Customer[],
  entries: CreditEntry[]
): { totalOut: number; breached: number; onTab: number } {
  let totalOut = 0;
  let breached = 0;
  let onTab = 0;
  for (const c of customers) {
    const { balance } = customerTotals(c.id, entries);
    if (balance > 0.004) {
      totalOut += balance;
      onTab += 1;
    }
    if (tabStatus(c, balance) === "breached") breached += 1;
  }
  return { totalOut: r2(totalOut), breached, onTab };
}

/* ============ Module E — Overheads & Break-Even ============ */

export const monthlyOverheads = (expenses: Expense[]): number =>
  r2(expenses.reduce((s, e) => s + e.amount, 0));

/**
 * Monthly Break-Even Turnover = Total Fixed Overheads / Avg Gross Margin %
 * Daily Sales Target         = Monthly Break-Even Turnover / 30
 */
export function breakEvenReport(
  expenses: Expense[],
  products: Product[]
): {
  overheads: number;
  avgMarginPct: number;
  marginBasis: "weighted" | "simple" | "default";
  monthlyBreakEven: number | null;
  dailyTarget: number | null;
} {
  const overheads = monthlyOverheads(expenses);
  const { pct, basis } = weightedAvgMargin(products);
  if (pct <= 0) {
    return {
      overheads,
      avgMarginPct: pct,
      marginBasis: basis,
      monthlyBreakEven: null,
      dailyTarget: null,
    };
  }
  const monthly = r2(overheads / (pct / 100));
  return {
    overheads,
    avgMarginPct: pct,
    marginBasis: basis,
    monthlyBreakEven: monthly,
    dailyTarget: r2(monthly / 30),
  };
}

/* ============ Module F — VAS Ledger ============ */

export interface VasSplit {
  commission: number; // net profit the shop keeps
  remit: number; // cash that must go back to the vendor float
}

/** Customer pays `amount`; shop keeps commission, remits the rest. */
export function vasSplit(amount: number, commissionPct: number): VasSplit {
  const commission = r2((amount * commissionPct) / 100);
  return { commission, remit: r2(amount - commission) };
}

export function vasSummary(txns: VasTxn[]): {
  sold: number;
  commission: number;
  remit: number;
  count: number;
} {
  let sold = 0;
  let commission = 0;
  for (const t of txns) {
    sold += t.amount;
    commission += vasSplit(t.amount, t.commissionPct).commission;
  }
  sold = r2(sold);
  commission = r2(commission);
  return { sold, commission, remit: r2(sold - commission), count: txns.length };
}

export function vasLabel(type: VasType): string {
  return VAS_META[type].label;
}
