/* ------------------------------------------------------------------ */
/* SPAZA — money helpers. Always ZAR, always 2dp, never floats out.    */
/* ------------------------------------------------------------------ */

/** Round to 2 decimal places (Rands & cents) with epsilon safety. */
export function r2(v: number): number {
  if (!Number.isFinite(v)) return 0;
  return Math.round((v + Number.EPSILON) * 100) / 100;
}

/**
 * Format a Rand value the way SA shop boards do:  R 1 234,56
 * (space-grouped thousands, comma decimals — hand-painted-sign style)
 */
export function fmtZAR(v: number, opts?: { sign?: boolean }): string {
  const n = r2(v);
  const neg = n < 0 || (opts?.sign && Object.is(n, -0));
  const abs = Math.abs(n);
  const [ints, dec] = abs.toFixed(2).split(".");
  const grouped = ints.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${neg ? "−" : opts?.sign && n !== 0 ? "+" : ""}R ${grouped},${dec}`;
}

/** Compact variant for tickers: R 12,4k */
export function fmtZARCompact(v: number): string {
  const n = r2(v);
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return `${n < 0 ? "−" : ""}R ${(abs / 1_000_000).toFixed(1).replace(".0", "").replace(".", ",")}m`;
  if (abs >= 1_000) return `${n < 0 ? "−" : ""}R ${(abs / 1_000).toFixed(1).replace(".0", "").replace(".", ",")}k`;
  return fmtZAR(n);
}

/** Parse a user-typed money string into a number (accepts "12,50", "R12.5"). */
export function parseMoney(raw: string): number {
  const clean = raw.replace(/[rR\s]/g, "").replace(",", ".");
  const n = Number(clean);
  return Number.isFinite(n) ? r2(n) : 0;
}

export function todayISO(): string {
  const d = new Date();
  const m = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `id-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}
