"use client";

/* ------------------------------------------------------------------ */
/* SPAZA — offline-first shop store                                    */
/*                                                                     */
/*   Every mutation:                                                   */
/*     1. updates React state instantly (zero-latency UI)              */
/*     2. is written to device storage (works during load shedding)    */
/*     3. syncs to PostgreSQL in the background when there's signal    */
/*                                                                     */
/*   Interlink rules enforced here (single source of truth):           */
/*     • Wholesale row change  → MIN() re-piped into product cost      */
/*     • Product delete        → cascades to matrix + delivery lines   */
/* ------------------------------------------------------------------ */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { bestWholesalePrice } from "./engine";
import { seedState } from "./seed";
import type {
  AppState,
  CollectionKey,
  CreditEntry,
  Customer,
  DeliveryLine,
  Expense,
  Product,
  VasTxn,
  WholesalerRow,
} from "./types";

const LS_KEY = "spaza.state.v1";
const SYNC_DEBOUNCE_MS = 1200;

export type SyncStatus = "synced" | "pending" | "offline" | "boot";

type Upsert =
  | { collection: "products"; item: Product }
  | { collection: "wholesalers"; item: WholesalerRow }
  | { collection: "deliveries"; item: DeliveryLine }
  | { collection: "customers"; item: Customer }
  | { collection: "creditEntries"; item: CreditEntry }
  | { collection: "expenses"; item: Expense }
  | { collection: "vasTxns"; item: VasTxn };

type Action =
  | ({ type: "upsert" } & Upsert)
  | { type: "replace"; state: AppState; silent?: boolean }
  | { type: "remove"; collection: CollectionKey; id: string }
  | { type: "deleteProduct"; id: string }
  | { type: "toggleCompliance"; stepId: string };

/** Pipe the matrix MIN() into linked product cost prices (auto-synced rows). */
function applyAutoSync(state: AppState): AppState {
  let products = state.products;
  let changed = false;
  for (const row of state.wholesalers) {
    if (!row.autoSync) continue;
    const best = bestWholesalePrice(row);
    if (!best) continue;
    const idx = products.findIndex((p) => p.id === row.productId);
    if (idx >= 0 && products[idx].costPrice !== best.value) {
      if (!changed) {
        products = [...products];
        changed = true;
      }
      products[idx] = { ...products[idx], costPrice: best.value };
    }
  }
  return changed ? { ...state, products } : state;
}

function stamp(state: AppState): AppState {
  return { ...state, updatedAt: new Date().toISOString() };
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "replace":
      return action.state;
    case "upsert": {
      const list = state[action.collection] as { id: string }[];
      const idx = list.findIndex((x) => x.id === action.item.id);
      const next =
        idx >= 0
          ? list.map((x, i) => (i === idx ? action.item : x))
          : [...list, action.item];
      const stamped = stamp({
        ...state,
        [action.collection]: next,
      } as AppState);
      return action.collection === "wholesalers" || action.collection === "products"
        ? applyAutoSync(stamped)
        : stamped;
    }
    case "remove": {
      const list = state[action.collection] as { id: string }[];
      const stamped = stamp({
        ...state,
        [action.collection]: list.filter((x) => x.id !== action.id),
      } as AppState);
      return action.collection === "wholesalers" || action.collection === "products"
        ? applyAutoSync(stamped)
        : stamped;
    }
    case "deleteProduct": {
      const stamped = stamp({
        ...state,
        products: state.products.filter((p) => p.id !== action.id),
        wholesalers: state.wholesalers.filter((w) => w.productId !== action.id),
        deliveries: state.deliveries.filter((d) => d.productId !== action.id),
      });
      return applyAutoSync(stamped);
    }
    case "toggleCompliance": {
      const compliance = { ...state.compliance };
      if (compliance[action.stepId]) delete compliance[action.stepId];
      else compliance[action.stepId] = true;
      return stamp({ ...state, compliance });
    }
    default:
      return state;
  }
}

interface Store {
  state: AppState;
  dispatch: React.Dispatch<Action>;
  sync: SyncStatus;
  online: boolean;
  /** force an immediate push to the server */
  flush: () => void;
}

const StoreCtx = createContext<Store | null>(null);

function readLocal(): AppState | null {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AppState;
    if (!parsed || !Array.isArray(parsed.products)) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, () => seedState());
  const [sync, setSync] = useState<SyncStatus>("boot");
  const [online, setOnline] = useState(true);

  const hydrated = useRef(false); // localStorage restored?
  const booted = useRef(false); // server handshake done?
  const dirty = useRef(false); // local edits awaiting sync?
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const stateRef = useRef(state);
  stateRef.current = state;

  /* ---- online / offline detection ---- */
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    update();
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => {
      window.removeEventListener("online", update);
      window.removeEventListener("offline", update);
    };
  }, []);

  const push = useCallback(async () => {
    if (!navigator.onLine) {
      setSync("offline");
      return;
    }
    try {
      const res = await fetch("/api/state", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(stateRef.current),
      });
      if (!res.ok) throw new Error(`PUT ${res.status}`);
      const body = (await res.json()) as { updatedAt?: string };
      if (body.updatedAt) {
        // adopt the server authoritative timestamp
        stateRef.current = { ...stateRef.current, updatedAt: body.updatedAt };
        try {
          localStorage.setItem(LS_KEY, JSON.stringify(stateRef.current));
        } catch {
          /* storage full — carry on */
        }
      }
      dirty.current = false;
      setSync("synced");
    } catch {
      dirty.current = true;
      setSync(navigator.onLine ? "pending" : "offline");
    }
  }, []);

  const schedulePush = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(push, SYNC_DEBOUNCE_MS);
  }, [push]);

  /* ---- boot: device cache first, then server handshake ---- */
  useEffect(() => {
    const local = readLocal();
    if (local) dispatch({ type: "replace", state: local });
    hydrated.current = true;

    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/state", { cache: "no-store" });
        if (!res.ok) throw new Error(`GET ${res.status}`);
        const server = (await res.json()) as AppState;
        if (cancelled) return;
        const localNow = stateRef.current;
        const serverIsNewer =
          !localNow.updatedAt ||
          new Date(server.updatedAt).getTime() >=
            new Date(localNow.updatedAt).getTime();
        if (serverIsNewer) {
          dispatch({ type: "replace", state: server });
          // If we had unsynced local edits, they lose (last-writer-wins).
          dirty.current = false;
          setSync("synced");
        } else if (dirty.current) {
          setSync("pending");
          schedulePush();
        } else {
          setSync("synced");
        }
      } catch {
        if (!cancelled) setSync(navigator.onLine ? "pending" : "offline");
      } finally {
        if (!cancelled) booted.current = true;
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---- persist locally + schedule cloud sync after every mutation ---- */
  useEffect(() => {
    if (!hydrated.current) return;
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(state));
    } catch {
      /* storage full — carry on with in-memory state */
    }
    if (!booted.current) return;
    dirty.current = true;
    setSync(navigator.onLine ? "pending" : "offline");
    schedulePush();
  }, [state, schedulePush]);

  /* ---- flush when signal returns or tab becomes visible ---- */
  useEffect(() => {
    const onOnline = () => {
      if (dirty.current) push();
    };
    const onVisible = () => {
      if (document.visibilityState === "visible" && dirty.current) push();
    };
    window.addEventListener("online", onOnline);
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.removeEventListener("online", onOnline);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [push]);

  const value = useMemo<Store>(
    () => ({ state, dispatch, sync, online, flush: push }),
    [state, sync, online, push]
  );

  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useShop(): Store {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error("useShop must be used inside <StoreProvider>");
  return ctx;
}

/* Small typed helpers for components */
export function upsertProduct(dispatch: Store["dispatch"], p: Product) {
  dispatch({ type: "upsert", collection: "products", item: p });
}
export function upsertWholesaler(dispatch: Store["dispatch"], w: WholesalerRow) {
  dispatch({ type: "upsert", collection: "wholesalers", item: w });
}
