/* ------------------------------------------------------------------ */
/* SPAZA — first-run seed: realistic township convenience-shop data    */
/* ------------------------------------------------------------------ */

import { todayISO } from "./money";
import type { AppState } from "./types";

function daysAgo(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  const m = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function seedState(): AppState {
  return {
    updatedAt: new Date().toISOString(),
    products: [
      {
        id: "p-bread",
        name: "White Bread 700g",
        category: "Bakery",
        costPrice: 13.5,
        marginPct: 26,
        overridePrice: null,
        stock: 18,
        reorderLevel: 20,
        supplier: "Daily Bread Truck",
      },
      {
        id: "p-milk",
        name: "Full Cream Milk 2L",
        category: "Dairy",
        costPrice: 28.0,
        marginPct: 20,
        overridePrice: 34.99,
        stock: 9,
        reorderLevel: 12,
        supplier: "Fresh Milk Delivery",
      },
      {
        id: "p-maize",
        name: "Ace Maize Meal 10kg",
        category: "Staples",
        costPrice: 109.0,
        marginPct: 19,
        overridePrice: null,
        stock: 14,
        reorderLevel: 6,
        supplier: "Boxer Superstore",
      },
      {
        id: "p-sugar",
        name: "White Sugar 2.5kg",
        category: "Staples",
        costPrice: 52.0,
        marginPct: 20,
        overridePrice: null,
        stock: 22,
        reorderLevel: 8,
        supplier: "Makro",
      },
      {
        id: "p-oil",
        name: "Cooking Oil 2L",
        category: "Staples",
        costPrice: 72.0,
        marginPct: 20,
        overridePrice: null,
        stock: 11,
        reorderLevel: 6,
        supplier: "Jumbo Cash",
      },
      {
        id: "p-rice",
        name: "Long Grain Rice 2kg",
        category: "Staples",
        costPrice: 38.0,
        marginPct: 24,
        overridePrice: null,
        stock: 16,
        reorderLevel: 8,
        supplier: "Makro",
      },
      {
        id: "p-eggs",
        name: "Eggs Large 30s",
        category: "Dairy",
        costPrice: 95.0,
        marginPct: 21,
        overridePrice: null,
        stock: 5,
        reorderLevel: 8,
        supplier: "Daily Bread Truck",
      },
      {
        id: "p-cola",
        name: "Soft Drink 2L",
        category: "Cooldrinks",
        costPrice: 22.0,
        marginPct: 24,
        overridePrice: 28.99,
        stock: 30,
        reorderLevel: 12,
        supplier: "Boxer Superstore",
      },
    ],
    wholesalers: [
      { id: "w-bread", productId: "p-bread", costA: 14.2, costB: 13.9, costC: 13.5, autoSync: true },
      { id: "w-milk", productId: "p-milk", costA: 28.0, costB: 28.75, costC: 28.5, autoSync: true },
      { id: "w-maize", productId: "p-maize", costA: 112.0, costB: 109.0, costC: 110.5, autoSync: true },
      { id: "w-sugar", productId: "p-sugar", costA: 52.0, costB: 53.5, costC: 52.9, autoSync: true },
      { id: "w-oil", productId: "p-oil", costA: 74.0, costB: 72.5, costC: 72.0, autoSync: true },
      { id: "w-rice", productId: "p-rice", costA: 38.0, costB: 39.2, costC: 38.6, autoSync: true },
      { id: "w-eggs", productId: "p-eggs", costA: 98.0, costB: 95.0, costC: 96.4, autoSync: true },
      { id: "w-cola", productId: "p-cola", costA: 23.1, costB: 22.0, costC: 22.6, autoSync: true },
    ],
    deliveries: [
      { id: "d-bread", productId: "p-bread", qtyPerDay: 40, daysPerWeek: 6 },
      { id: "d-milk", productId: "p-milk", qtyPerDay: 20, daysPerWeek: 6 },
      { id: "d-eggs", productId: "p-eggs", qtyPerDay: 6, daysPerWeek: 3 },
    ],
    customers: [
      { id: "c-thandi", name: "Thandi Mokoena", phone: "082 555 0147", creditLimit: 300 },
      { id: "c-sipho", name: "Sipho Ndlovu", phone: "073 555 0193", creditLimit: 250 },
      { id: "c-gogo", name: "Gogo Maria Khoza", phone: "060 555 0112", creditLimit: 150 },
    ],
    creditEntries: [
      { id: "e-1", customerId: "c-thandi", date: daysAgo(4), item: "Bread + milk for the week", credit: 86, payment: 0 },
      { id: "e-2", customerId: "c-thandi", date: daysAgo(2), item: "Part payment", credit: 0, payment: 50 },
      { id: "e-3", customerId: "c-sipho", date: daysAgo(6), item: "Maize meal + cooking oil", credit: 232, payment: 0 },
      { id: "e-4", customerId: "c-sipho", date: daysAgo(1), item: "Sugar 2.5kg", credit: 40, payment: 0 },
      { id: "e-5", customerId: "c-gogo", date: daysAgo(8), item: "Pension-week groceries", credit: 60, payment: 0 },
      { id: "e-6", customerId: "c-gogo", date: daysAgo(3), item: "Paid in full", credit: 0, payment: 60 },
    ],
    expenses: [
      { id: "x-rent", category: "Rent", label: "Container + yard rental", amount: 3500 },
      { id: "x-elec", category: "Electricity", label: "Commercial prepaid tokens", amount: 1800 },
      { id: "x-petrol", category: "Transport", label: "Bakkie petrol — buying trips", amount: 1150 },
      { id: "x-data", category: "Data", label: "Card machine + WhatsApp data", amount: 349 },
    ],
    vasTxns: [
      { id: "v-1", date: todayISO(), type: "electricity", amount: 200, commissionPct: 2.5, reference: "Meter 07••••221" },
      { id: "v-2", date: todayISO(), type: "airtime", amount: 50, commissionPct: 5, reference: "Vodacom voucher" },
      { id: "v-3", date: daysAgo(1), type: "bills", amount: 479, commissionPct: 2, reference: "DSTV Compact" },
      { id: "v-4", date: daysAgo(1), type: "electricity", amount: 100, commissionPct: 2.5, reference: "Meter 04••••810" },
    ],
    compliance: {
      "cipc.1": true,
      "cipc.2": true,
      "sars.1": true,
      "coa.4": true,
    },
  };
}
