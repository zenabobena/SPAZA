"use client";

/* ------------------------------------------------------------------ */
/* SPAZA — Module D: Customer Credit Book ("Tab" tracker)              */
/* Guardrail: outstanding > limit ⇒ CREDIT LIMIT BREACHED, and the     */
/* till refuses new tab entries until a repayment brings it back.      */
/* ------------------------------------------------------------------ */

import {
  canIssueCredit,
  creditSummary,
  customerTotals,
  tabStatus,
  type TabStatus,
} from "@/lib/engine";
import { fmtZAR, parseMoney, todayISO, uid } from "@/lib/money";
import { useShop } from "@/lib/store";
import type { CreditEntry, Customer } from "@/lib/types";
import {
  Banknote,
  BookUser,
  ChevronDown,
  Lock,
  Phone,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import { useState } from "react";
import { Bar, Btn, Card, Empty, Field, NumInput, SectionHead, Sticker, TextInput } from "./ui";

const STATUS_META: Record<TabStatus, { label: string; tone: "green" | "gold" | "red" | "blue"; bar: "green" | "gold" | "red" }> = {
  clear: { label: "Settled up", tone: "green", bar: "green" },
  good: { label: "On tab", tone: "blue", bar: "green" },
  near: { label: "Near limit", tone: "gold", bar: "gold" },
  breached: { label: "Credit limit breached", tone: "red", bar: "red" },
};

/* ---------------- new customer form ---------------- */

function NewCustomer({ onDone }: { onDone: () => void }) {
  const { dispatch } = useShop();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [limit, setLimit] = useState("200");
  return (
    <Card className="space-y-3 p-3">
      <div className="grid grid-cols-2 gap-2.5">
        <div className="col-span-2">
          <Field label="Customer name">
            <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Thandi Mokoena" />
          </Field>
        </div>
        <Field label="Contact number">
          <TextInput inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="082 000 0000" />
        </Field>
        <Field label="Max credit limit (R)">
          <NumInput value={limit} onChange={(e) => setLimit(e.target.value)} placeholder="200" />
        </Field>
      </div>
      <div className="flex gap-2">
        <Btn
          variant="green"
          className="flex-1"
          disabled={!name.trim()}
          onClick={() => {
            const c: Customer = {
              id: uid(),
              name: name.trim(),
              phone: phone.trim(),
              creditLimit: Math.max(0, parseMoney(limit)),
            };
            dispatch({ type: "upsert", collection: "customers", item: c });
            onDone();
          }}
        >
          Add customer
        </Btn>
        <Btn variant="outline" icon={X} onClick={onDone}>Cancel</Btn>
      </div>
    </Card>
  );
}

/* ---------------- tab / payment entry form ---------------- */

function EntryForm({
  customer,
  balance,
  initialKind,
  onDone,
}: {
  customer: Customer;
  balance: number;
  initialKind: "credit" | "payment";
  onDone: () => void;
}) {
  const { dispatch } = useShop();
  const [kind, setKind] = useState<"credit" | "payment">(initialKind);
  const [item, setItem] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(todayISO());
  const [error, setError] = useState<string | null>(null);

  const save = () => {
    const amt = parseMoney(amount);
    if (amt <= 0) return setError("Enter an amount above zero.");
    if (kind === "credit") {
      const gate = canIssueCredit(customer, balance, amt);
      if (!gate.ok) return setError(gate.reason);
    }
    const entry: CreditEntry = {
      id: uid(),
      customerId: customer.id,
      date,
      item: item.trim() || (kind === "credit" ? "Tab purchase" : "Repayment"),
      credit: kind === "credit" ? amt : 0,
      payment: kind === "payment" ? amt : 0,
    };
    dispatch({ type: "upsert", collection: "creditEntries", item: entry });
    onDone();
  };

  return (
    <div className="space-y-2.5 rounded-lg border-2 border-ink bg-paper p-3">
      <div className="grid grid-cols-2 gap-1 rounded-lg border-2 border-ink bg-white p-1">
        {(["credit", "payment"] as const).map((k) => (
          <button
            key={k}
            onClick={() => {
              setKind(k);
              setError(null);
            }}
            className={`cursor-pointer rounded-md px-2 py-1.5 text-[11px] font-extrabold uppercase tracking-wide ${
              kind === k
                ? k === "credit"
                  ? "bg-brand-red text-white"
                  : "bg-brand-green text-white"
                : "text-ink/45"
            }`}
          >
            {k === "credit" ? "New tab" : "Payment"}
          </button>
        ))}
      </div>
      <Field label={kind === "credit" ? "Item / reason" : "Note"}>
        <TextInput
          value={item}
          onChange={(e) => setItem(e.target.value)}
          placeholder={kind === "credit" ? "e.g. Bread + 2L milk" : "e.g. Cash repayment"}
        />
      </Field>
      <div className="grid grid-cols-2 gap-2.5">
        <Field label="Amount (R)">
          <NumInput value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0,00" />
        </Field>
        <Field label="Date">
          <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
      </div>
      {error && (
        <p className="rounded-md border-2 border-brand-red bg-red-50 px-2.5 py-1.5 text-[11px] font-extrabold text-brand-red">
          {error}
        </p>
      )}
      <div className="flex gap-2">
        <Btn
          variant={kind === "credit" ? "red" : "green"}
          size="sm"
          className="flex-1"
          onClick={save}
        >
          {kind === "credit" ? "Write the tab" : "Bank the payment"}
        </Btn>
        <Btn variant="ghost" size="sm" onClick={onDone}>Cancel</Btn>
      </div>
    </div>
  );
}

/* ---------------- one customer card ---------------- */

function CustomerCard({ customer }: { customer: Customer }) {
  const { state, dispatch } = useShop();
  const [open, setOpen] = useState(false);
  const [entryKind, setEntryKind] = useState<"credit" | "payment" | null>(null);
  const [editingLimit, setEditingLimit] = useState(false);
  const [limitDraft, setLimitDraft] = useState("");

  const totals = customerTotals(customer.id, state.creditEntries);
  const status = tabStatus(customer, totals.balance);
  const meta = STATUS_META[status];
  const entries = state.creditEntries
    .filter((e) => e.customerId === customer.id)
    .sort((a, b) => (a.date < b.date ? 1 : -1));
  const breached = status === "breached";
  const pct = customer.creditLimit > 0 ? totals.balance / customer.creditLimit : 1;

  return (
    <Card className={breached ? "bg-red-50" : ""}>
      <button onClick={() => setOpen((o) => !o)} className="block w-full cursor-pointer p-3 text-left">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-1.5">
              <Sticker tone={meta.tone} rotate={false}>{meta.label}</Sticker>
              {breached && (
                <Sticker tone="ink" rotate={false}>
                  <Lock className="size-2.5" /> tabs locked
                </Sticker>
              )}
            </div>
            <div className="mt-1 truncate text-[15px] font-extrabold">{customer.name}</div>
            {customer.phone ? (
              <a
                href={`tel:${customer.phone.replace(/\s+/g, "")}`}
                onClick={(e) => e.stopPropagation()}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-brand-blue"
              >
                <Phone className="size-3" /> {customer.phone}
              </a>
            ) : (
              <span className="text-[11px] font-semibold text-ink/40">no number saved</span>
            )}
          </div>
          <div className="shrink-0 text-right">
            <div
              className={`font-display text-2xl leading-none tabular-nums ${
                breached ? "text-brand-red" : totals.balance > 0 ? "" : "text-brand-green"
              }`}
            >
              {fmtZAR(Math.max(0, totals.balance))}
            </div>
            <div className="mt-0.5 text-[10px] font-bold text-ink/50">
              owes · limit {fmtZAR(customer.creditLimit)}
            </div>
          </div>
        </div>
        <div className="mt-2.5 flex items-center gap-2">
          <Bar pct={Math.max(0, pct)} tone={meta.bar} />
          <ChevronDown className={`size-4 shrink-0 text-ink/40 transition-transform ${open ? "rotate-180" : ""}`} />
        </div>
      </button>

      {open && (
        <div className="space-y-3 border-t-2 border-ink/10 px-3 py-3">
          {/* guardrail banner */}
          {breached ? (
            <div className="flex items-start gap-2 rounded-lg border-2 border-brand-red bg-white p-2.5">
              <Lock className="mt-0.5 size-4 shrink-0 text-brand-red" />
              <p className="text-[11px] leading-snug font-bold text-brand-red">
                CREDIT LIMIT BREACHED by {fmtZAR(totals.balance - customer.creditLimit)}. No new
                tabs can be written until a repayment brings the balance under{" "}
                {fmtZAR(customer.creditLimit)}.
              </p>
            </div>
          ) : (
            <p className="text-[11px] font-bold text-ink/55">
              Headroom: {fmtZAR(Math.max(0, customer.creditLimit - totals.balance))} before the
              limit. Total advanced {fmtZAR(totals.credit)} · repaid {fmtZAR(totals.paid)}.
            </p>
          )}

          {/* actions */}
          <div className="flex gap-2">
            <Btn
              variant="red"
              size="sm"
              className="flex-1"
              icon={breached ? Lock : Plus}
              disabled={breached}
              onClick={() => setEntryKind("credit")}
            >
              New tab entry
            </Btn>
            <Btn
              variant="green"
              size="sm"
              className="flex-1"
              icon={Banknote}
              onClick={() => setEntryKind("payment")}
            >
              Log payment
            </Btn>
          </div>

          {entryKind && (
            <EntryForm
              customer={customer}
              balance={totals.balance}
              initialKind={entryKind}
              onDone={() => setEntryKind(null)}
            />
          )}

          {/* ledger */}
          <div>
            <div className="mb-1 text-[10px] font-extrabold uppercase tracking-[0.12em] text-ink/50">
              Ledger ({entries.length})
            </div>
            {entries.length === 0 ? (
              <p className="text-[11px] font-semibold text-ink/40">No movements yet.</p>
            ) : (
              <div className="max-h-56 space-y-1 overflow-y-auto pr-1">
                {entries.map((e) => (
                  <div
                    key={e.id}
                    className="flex items-center gap-2 rounded-md border border-ink/15 bg-white px-2 py-1.5"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[11px] font-bold">{e.item}</div>
                      <div className="text-[9px] font-semibold text-ink/45">{e.date}</div>
                    </div>
                    <div
                      className={`text-[12px] font-extrabold tabular-nums ${
                        e.credit > 0 ? "text-brand-red" : "text-brand-green"
                      }`}
                    >
                      {e.credit > 0 ? `+${fmtZAR(e.credit)}` : `−${fmtZAR(e.payment)}`}
                    </div>
                    <button
                      aria-label="Delete entry"
                      onClick={() => dispatch({ type: "remove", collection: "creditEntries", id: e.id })}
                      className="cursor-pointer text-ink/25 hover:text-brand-red"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* limit edit + danger */}
          <div className="flex items-center justify-between gap-2 border-t border-dashed border-ink/20 pt-2.5">
            {editingLimit ? (
              <div className="flex flex-1 items-center gap-2">
                <NumInput
                  value={limitDraft}
                  onChange={(e) => setLimitDraft(e.target.value)}
                  className="max-w-28 py-1.5 text-sm"
                />
                <Btn
                  size="sm"
                  variant="green"
                  onClick={() => {
                    dispatch({
                      type: "upsert",
                      collection: "customers",
                      item: { ...customer, creditLimit: Math.max(0, parseMoney(limitDraft)) },
                    });
                    setEditingLimit(false);
                  }}
                >
                  Save limit
                </Btn>
                <Btn size="sm" variant="ghost" onClick={() => setEditingLimit(false)}>×</Btn>
              </div>
            ) : (
              <button
                onClick={() => {
                  setLimitDraft(String(customer.creditLimit));
                  setEditingLimit(true);
                }}
                className="cursor-pointer text-[10px] font-extrabold uppercase tracking-wide text-brand-blue"
              >
                Change limit
              </button>
            )}
            <button
              onClick={() => {
                dispatch({ type: "remove", collection: "customers", id: customer.id });
              }}
              className="cursor-pointer text-[10px] font-extrabold uppercase tracking-wide text-ink/35 hover:text-brand-red"
            >
              Remove customer
            </button>
          </div>
        </div>
      )}
    </Card>
  );
}

/* ---------------- pane ---------------- */

export function CreditPane() {
  const { state } = useShop();
  const [adding, setAdding] = useState(false);
  const sum = creditSummary(state.customers, state.creditEntries);

  const sorted = [...state.customers].sort((a, b) => {
    const ba = customerTotals(a.id, state.creditEntries).balance;
    const bb = customerTotals(b.id, state.creditEntries).balance;
    return bb - ba;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-end justify-between gap-2">
        <div>
          <div className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-brand-red">
            Module D
          </div>
          <h1 className="font-display text-3xl tracking-tight">Tab Book</h1>
          <p className="mt-0.5 text-xs font-semibold text-ink/55">
            {fmtZAR(sum.totalOut)} outstanding · {sum.onTab} customers on tab ·{" "}
            {sum.breached} over limit
          </p>
        </div>
        {!adding && (
          <Btn size="sm" icon={Plus} onClick={() => setAdding(true)}>
            Customer
          </Btn>
        )}
      </div>

      {adding && <NewCustomer onDone={() => setAdding(false)} />}

      <SectionHead kicker="Trust, but with limits" title="Customers" />

      {state.customers.length === 0 ? (
        <Empty
          icon={BookUser}
          title="No customers on the book"
          body="Add a regular customer with a credit limit, then write tabs and log repayments. The guardrails do the rest."
        />
      ) : (
        <div className="space-y-2.5">
          {sorted.map((c) => (
            <CustomerCard key={c.id} customer={c} />
          ))}
        </div>
      )}

      <p className="pb-2 text-[11px] leading-relaxed font-semibold text-ink/50">
        House rule the app enforces for you: once a tab passes its limit, the
        customer must pay some money back before any new tab is written. No
        arguments at the counter.
      </p>
    </div>
  );
}
