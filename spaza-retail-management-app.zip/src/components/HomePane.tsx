"use client";

/* ------------------------------------------------------------------ */
/* SPAZA — Home: the daily control tower                               */
/* ------------------------------------------------------------------ */

import {
  breakEvenReport,
  creditSummary,
  customerTotals,
  floatReport,
  isReorder,
  sellingPrice,
  stockValueAtCost,
  stockValueAtRetail,
  tabStatus,
  vasSummary,
} from "@/lib/engine";
import { fmtZAR, fmtZARCompact } from "@/lib/money";
import { useShop } from "@/lib/store";
import {
  AlarmClock,
  ArrowRight,
  Banknote,
  BookUser,
  Boxes,
  ShieldCheck,
  Target,
  Truck,
  Zap,
} from "lucide-react";
import { Bar, Card, Compact, SectionHead, Sticker } from "./ui";
import type { Tab } from "./App";

export function HomePane({ go }: { go: (t: Tab) => void }) {
  const { state } = useShop();
  const be = breakEvenReport(state.expenses, state.products);
  const credit = creditSummary(state.customers, state.creditEntries);
  const float = floatReport(state.deliveries, state.products);
  const vas = vasSummary(state.vasTxns);
  const stockCost = stockValueAtCost(state.products);
  const stockRetail = stockValueAtRetail(state.products);
  const low = state.products.filter(isReorder);
  const potentialGP = stockRetail - stockCost;

  const breachedCustomers = state.customers.filter(
    (c) => tabStatus(c, customerTotals(c.id, state.creditEntries).balance) === "breached"
  );

  const tickerItems = [
    ...low.map((p) => `REORDER: ${p.name} (${p.stock} left)`),
    ...breachedCustomers.map((c) => `${c.name} OVER LIMIT — NO NEW TABS`),
    ...(vas.count > 0 ? [`VAS commission banked: ${fmtZAR(vas.commission)}`] : []),
  ];

  return (
    <div className="space-y-5">
      {/* greeting */}
      <div>
        <div className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-brand-red">
          Control tower
        </div>
        <h1 className="font-display text-3xl tracking-tight">Sawubona, Boss</h1>
        <p className="mt-0.5 text-xs font-semibold text-ink/55">
          Here is what the shop needs from you today.
        </p>
      </div>

      {/* alert ticker */}
      {tickerItems.length > 0 && (
        <div className="overflow-hidden rounded-lg border-2 border-ink bg-ink py-1.5 shadow-hard-sm">
          <div className="animate-marquee flex w-max items-center gap-8 pr-8">
            {[...tickerItems, ...tickerItems].map((t, i) => (
              <span
                key={i}
                className="flex items-center gap-2 text-[11px] font-extrabold tracking-wide whitespace-nowrap text-gold uppercase"
              >
                <AlarmClock className="size-3.5 text-brand-red" strokeWidth={3} />
                {t}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* the number that matters */}
      <Card tone="gold" className="relative overflow-hidden p-4">
        <div className="absolute -top-6 -right-6 size-28 rounded-full border-[10px] border-ink/10" />
        <Sticker tone="ink" rotate={false}>
          <Target className="size-3" /> Today&apos;s survival number
        </Sticker>
        {be.dailyTarget !== null ? (
          <>
            <div className="mt-2 font-display text-[44px] leading-none tracking-tight tabular-nums">
              {fmtZAR(be.dailyTarget)}
            </div>
            <p className="mt-1.5 text-[11px] leading-snug font-bold text-ink/70">
              Daily sales needed to cover {fmtZAR(be.overheads)} monthly overheads at
              your average {be.avgMarginPct}% gross margin. Break-even month:{" "}
              {be.monthlyBreakEven !== null ? <Compact v={be.monthlyBreakEven} /> : "—"}.
            </p>
          </>
        ) : (
          <p className="mt-2 text-sm font-bold">
            Set product margins and overheads to unlock your break-even target.
          </p>
        )}
      </Card>

      {/* shop vitals */}
      <div className="grid grid-cols-2 gap-2.5">
        <button onClick={() => go("stock")} className="text-left">
          <Card className="h-full cursor-pointer p-3 transition-transform hover:-translate-y-0.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-extrabold uppercase tracking-[0.09em] text-ink/60">Stock value</span>
              <Boxes className="size-4 text-ink/40" />
            </div>
            <div className="mt-1 font-display text-2xl tabular-nums">{fmtZARCompact(stockCost)}</div>
            <div className="mt-0.5 text-[10px] font-bold text-ink/50">
              sells for {fmtZARCompact(stockRetail)} · GP {fmtZARCompact(potentialGP)}
            </div>
          </Card>
        </button>
        <button onClick={() => go("credit")} className="text-left">
          <Card className="h-full cursor-pointer p-3 transition-transform hover:-translate-y-0.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-extrabold uppercase tracking-[0.09em] text-ink/60">Out on tabs</span>
              <BookUser className="size-4 text-ink/40" />
            </div>
            <div className="mt-1 font-display text-2xl tabular-nums">{fmtZARCompact(credit.totalOut)}</div>
            <div className="mt-0.5 text-[10px] font-bold text-ink/50">
              {credit.onTab} customers owe · {credit.breached} over limit
            </div>
            <div className="mt-2">
              <Bar
                pct={credit.breached > 0 ? 1 : 0.15}
                tone={credit.breached > 0 ? "red" : "green"}
              />
            </div>
          </Card>
        </button>
        <button onClick={() => go("money")} className="text-left">
          <Card className="h-full cursor-pointer p-3 transition-transform hover:-translate-y-0.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-extrabold uppercase tracking-[0.09em] text-ink/60">Truck float</span>
              <Truck className="size-4 text-ink/40" />
            </div>
            <div className="mt-1 font-display text-2xl tabular-nums">{fmtZARCompact(float.totalWeekly)}</div>
            <div className="mt-0.5 text-[10px] font-bold text-ink/50">cash to reserve this week</div>
          </Card>
        </button>
        <button onClick={() => go("money")} className="text-left">
          <Card className="h-full cursor-pointer p-3 transition-transform hover:-translate-y-0.5">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-extrabold uppercase tracking-[0.09em] text-ink/60">VAS profit</span>
              <Zap className="size-4 text-ink/40" />
            </div>
            <div className="mt-1 font-display text-2xl text-brand-green tabular-nums">
              {fmtZARCompact(vas.commission)}
            </div>
            <div className="mt-0.5 text-[10px] font-bold text-ink/50">
              commission on {fmtZARCompact(vas.sold)} vended
            </div>
          </Card>
        </button>
      </div>

      {/* reorder alerts */}
      <section>
        <SectionHead
          kicker="Stock radar"
          title={`Reorder alerts (${low.length})`}
          action={
            <button
              onClick={() => go("stock")}
              className="flex items-center gap-1 text-[11px] font-extrabold uppercase tracking-wide text-brand-blue"
            >
              Stock <ArrowRight className="size-3.5" strokeWidth={3} />
            </button>
          }
        />
        {low.length === 0 ? (
          <Card className="p-3">
            <p className="text-xs font-bold text-ink/60">
              Shelves are healthy — nothing below its reorder level.
            </p>
          </Card>
        ) : (
          <div className="space-y-2">
            {low.slice(0, 4).map((p) => (
              <Card key={p.id} className="flex items-center gap-3 bg-red-50 p-3">
                <Sticker tone="red" rotate={false}>Reorder alert</Sticker>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-extrabold">{p.name}</div>
                  <div className="text-[11px] font-semibold text-ink/55">
                    {p.stock} on hand · min {p.reorderLevel} · {p.supplier}
                  </div>
                </div>
                <div className="text-right text-[11px] font-extrabold text-ink/60">
                  {fmtZAR(sellingPrice(p))}
                </div>
              </Card>
            ))}
            {low.length > 4 && (
              <button
                onClick={() => go("stock")}
                className="w-full text-center text-[11px] font-extrabold uppercase tracking-wide text-brand-blue"
              >
                +{low.length - 4} more in Stock
              </button>
            )}
          </div>
        )}
      </section>

      {/* breached tabs */}
      {breachedCustomers.length > 0 && (
        <section>
          <SectionHead kicker="Credit risk" title="Tabs over the limit" />
          <div className="space-y-2">
            {breachedCustomers.map((c) => {
              const t = customerTotals(c.id, state.creditEntries);
              return (
                <Card key={c.id} className="flex items-center gap-3 bg-red-50 p-3">
                  <Sticker tone="red" rotate={false}>No new tabs</Sticker>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-extrabold">{c.name}</div>
                    <div className="text-[11px] font-semibold text-ink/55">
                      limit {fmtZAR(c.creditLimit)} · over by {fmtZAR(t.balance - c.creditLimit)}
                    </div>
                  </div>
                  <div className="text-right text-[11px] font-extrabold text-brand-red tabular-nums">
                    {fmtZAR(t.balance)}
                  </div>
                </Card>
              );
            })}
          </div>
        </section>
      )}

      {/* quick actions */}
      <section>
        <SectionHead kicker="Do it now" title="Quick actions" />
        <div className="grid grid-cols-4 gap-2">
          {(
            [
              { icon: Boxes, label: "Stock & prices", tab: "stock", tone: "green" },
              { icon: BookUser, label: "Write a tab", tab: "credit", tone: "gold" },
              { icon: Zap, label: "Sell VAS", tab: "money", tone: "blue" },
              { icon: ShieldCheck, label: "Comply", tab: "comply", tone: "red" },
            ] as const
          ).map(({ icon: Icon, label, tab, tone }) => (
            <button
              key={tab + tone}
              onClick={() => go(tab)}
              className="flex cursor-pointer flex-col items-center gap-1.5 rounded-xl border-2 border-ink bg-white px-1 py-3 shadow-hard-xs transition-transform hover:-translate-y-0.5 active:translate-y-0.5 active:shadow-none"
            >
              <span
                className={`flex size-9 items-center justify-center rounded-lg border-2 border-ink ${
                  tone === "green"
                    ? "bg-brand-green text-white"
                    : tone === "blue"
                      ? "bg-brand-blue text-white"
                      : tone === "red"
                        ? "bg-brand-red text-white"
                        : "bg-gold text-ink"
                }`}
              >
                <Icon className="size-4.5" strokeWidth={2.6} />
              </span>
              <span className="text-center text-[9px] leading-tight font-extrabold uppercase tracking-wide">
                {label}
              </span>
            </button>
          ))}
        </div>
      </section>

      <p className="pt-1 pb-2 text-center text-[10px] font-extrabold uppercase tracking-[0.2em] text-ink/35">
        <Banknote className="mr-1 inline size-3" /> Every rand counted · even offline
      </p>
    </div>
  );
}
