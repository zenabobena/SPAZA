"use client";

/* ------------------------------------------------------------------ */
/* SPAZA — design system primitives                                    */
/* Look: hand-painted township shop signage — thick ink borders,       */
/* offset hard shadows, sticker badges, SA-flag accent palette.        */
/* ------------------------------------------------------------------ */

import { fmtZARCompact } from "@/lib/money";
import type { LucideIcon } from "lucide-react";
import { Inbox } from "lucide-react";
import type {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
} from "react";

/* ---------------- Card ---------------- */

export function Card({
  children,
  className = "",
  tone = "white",
}: {
  children: ReactNode;
  className?: string;
  tone?: "white" | "paper" | "ink" | "gold" | "green" | "red" | "blue";
}) {
  const tones: Record<string, string> = {
    white: "bg-white text-ink",
    paper: "bg-paper-deep text-ink",
    ink: "bg-ink text-paper",
    gold: "bg-gold text-ink",
    green: "bg-brand-green text-white",
    red: "bg-brand-red text-white",
    blue: "bg-brand-blue text-white",
  };
  return (
    <div
      className={`rounded-xl border-2 border-ink shadow-hard ${tones[tone]} ${className}`}
    >
      {children}
    </div>
  );
}

/* ---------------- Sticker badge ---------------- */

export function Sticker({
  children,
  tone = "gold",
  rotate = true,
  className = "",
}: {
  children: ReactNode;
  tone?: "gold" | "red" | "green" | "ink" | "blue" | "paper";
  rotate?: boolean;
  className?: string;
}) {
  const tones: Record<string, string> = {
    gold: "bg-gold text-ink",
    red: "bg-brand-red text-white",
    green: "bg-brand-green text-white",
    blue: "bg-brand-blue text-white",
    ink: "bg-ink text-paper",
    paper: "bg-paper text-ink",
  };
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-md border-2 border-ink px-1.5 py-0.5 text-[10px] font-extrabold uppercase tracking-[0.08em] ${tones[tone]} ${
        rotate ? "-rotate-1" : ""
      } ${className}`}
    >
      {children}
    </span>
  );
}

/* ---------------- Button ---------------- */

interface BtnProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "ink" | "outline" | "gold" | "green" | "red" | "ghost";
  size?: "sm" | "md" | "lg";
  icon?: LucideIcon;
}

export function Btn({
  children,
  variant = "ink",
  size = "md",
  icon: Icon,
  className = "",
  ...rest
}: BtnProps) {
  const variants: Record<string, string> = {
    ink: "bg-ink text-paper border-ink shadow-hard-sm hover:bg-ink-soft",
    outline: "bg-white text-ink border-ink shadow-hard-sm hover:bg-paper-deep",
    gold: "bg-gold text-ink border-ink shadow-hard-sm hover:bg-gold-deep",
    green: "bg-brand-green text-white border-ink shadow-hard-sm hover:brightness-110",
    red: "bg-brand-red text-white border-ink shadow-hard-sm hover:brightness-110",
    ghost: "bg-transparent text-ink border-transparent hover:bg-ink/5",
  };
  const sizes: Record<string, string> = {
    sm: "min-h-9 px-3 text-xs",
    md: "min-h-11 px-4 text-sm",
    lg: "min-h-13 px-5 text-base",
  };
  return (
    <button
      {...rest}
      className={`inline-flex cursor-pointer items-center justify-center gap-2 rounded-lg border-2 font-extrabold uppercase tracking-wide transition-all duration-100 active:translate-x-[2px] active:translate-y-[2px] active:shadow-none disabled:cursor-not-allowed disabled:opacity-40 disabled:shadow-none disabled:active:translate-x-0 disabled:active:translate-y-0 ${variants[variant]} ${sizes[size]} ${className}`}
    >
      {Icon ? <Icon className="size-4" strokeWidth={2.6} /> : null}
      {children}
    </button>
  );
}

/* ---------------- Form fields ---------------- */

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-extrabold uppercase tracking-[0.1em] text-ink/70">
        {label}
      </span>
      {children}
      {hint ? (
        <span className="mt-1 block text-[11px] leading-snug text-ink/50">{hint}</span>
      ) : null}
    </label>
  );
}

const inputBase =
  "w-full rounded-lg border-2 border-ink bg-white px-3 py-2.5 text-[15px] font-semibold text-ink outline-none transition-shadow placeholder:font-medium placeholder:text-ink/30 focus:shadow-hard-sm";

export function TextInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`${inputBase} ${props.className ?? ""}`} />;
}

export function NumInput(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      inputMode="decimal"
      {...props}
      className={`${inputBase} tabular-nums ${props.className ?? ""}`}
    />
  );
}

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  children: ReactNode;
}
export function Select({ children, ...rest }: SelectProps) {
  return (
    <select {...rest} className={`${inputBase} appearance-none pr-8 ${rest.className ?? ""}`}>
      {children}
    </select>
  );
}

/* ---------------- Segmented control ---------------- */

export function Seg<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string; icon?: LucideIcon }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div
      role="tablist"
      className="flex gap-1 overflow-x-auto rounded-xl border-2 border-ink bg-ink p-1 shadow-hard-sm no-scrollbar"
    >
      {options.map((o) => {
        const active = o.value === value;
        const Icon = o.icon;
        return (
          <button
            key={o.value}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(o.value)}
            className={`flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-[11px] font-extrabold uppercase tracking-wide whitespace-nowrap transition-colors ${
              active
                ? "bg-gold text-ink shadow-[inset_0_0_0_2px_var(--ink)]"
                : "text-paper/60 hover:text-paper"
            }`}
          >
            {Icon ? <Icon className="size-3.5" strokeWidth={2.8} /> : null}
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

/* ---------------- Stat tile ---------------- */

export function StatTile({
  label,
  value,
  sub,
  icon: Icon,
  accent = "gold",
  alert = false,
}: {
  label: string;
  value: string;
  sub?: string;
  icon?: LucideIcon;
  accent?: "gold" | "green" | "red" | "blue" | "ink";
  alert?: boolean;
}) {
  const bars: Record<string, string> = {
    gold: "bg-gold",
    green: "bg-brand-green",
    red: "bg-brand-red",
    blue: "bg-brand-blue",
    ink: "bg-ink",
  };
  return (
    <div
      className={`relative overflow-hidden rounded-xl border-2 border-ink bg-white p-3 shadow-hard-sm ${
        alert ? "bg-red-50" : ""
      }`}
    >
      <div className={`absolute inset-x-0 top-0 h-1.5 ${bars[accent]}`} />
      <div className="mt-1 flex items-start justify-between gap-2">
        <span className="text-[10px] leading-tight font-extrabold uppercase tracking-[0.09em] text-ink/60">
          {label}
        </span>
        {Icon ? <Icon className="size-4 shrink-0 text-ink/40" strokeWidth={2.4} /> : null}
      </div>
      <div className="mt-1 font-display text-[22px] leading-none tracking-tight tabular-nums">
        {value}
      </div>
      {sub ? (
        <div className="mt-1 text-[11px] leading-tight font-semibold text-ink/50">{sub}</div>
      ) : null}
    </div>
  );
}

/* ---------------- Section head ---------------- */

export function SectionHead({
  kicker,
  title,
  action,
}: {
  kicker?: string;
  title: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-3 flex items-end justify-between gap-3">
      <div>
        {kicker ? (
          <div className="mb-0.5 text-[10px] font-extrabold uppercase tracking-[0.18em] text-brand-red">
            {kicker}
          </div>
        ) : null}
        <h2 className="font-display text-xl tracking-tight">{title}</h2>
      </div>
      {action}
    </div>
  );
}

/* ---------------- Empty state ---------------- */

export function Empty({
  icon: Icon = Inbox,
  title,
  body,
  action,
}: {
  icon?: LucideIcon;
  title: string;
  body?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border-2 border-dashed border-ink/30 bg-white/50 px-4 py-8 text-center">
      <Icon className="size-7 text-ink/30" strokeWidth={2} />
      <div className="text-sm font-extrabold uppercase tracking-wide">{title}</div>
      {body ? <p className="max-w-[30ch] text-xs leading-relaxed text-ink/55">{body}</p> : null}
      {action}
    </div>
  );
}

/* ---------------- Limit / progress bar ---------------- */

export function Bar({
  pct,
  tone = "gold",
}: {
  pct: number; // 0..1+
  tone?: "gold" | "green" | "red" | "blue" | "ink";
}) {
  const tones: Record<string, string> = {
    gold: "bg-gold",
    green: "bg-brand-green",
    red: "bg-brand-red",
    blue: "bg-brand-blue",
    ink: "bg-ink",
  };
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full border-2 border-ink bg-white">
      <div
        className={`h-full ${tones[tone]} transition-all duration-300`}
        style={{ width: `${Math.min(100, Math.max(0, pct * 100))}%` }}
      />
    </div>
  );
}

/* ---------------- Money display ---------------- */

export function Compact({ v }: { v: number }) {
  return <span className="tabular-nums">{fmtZARCompact(v)}</span>;
}
