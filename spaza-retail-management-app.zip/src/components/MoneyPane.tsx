"use client";

/* ------------------------------------------------------------------ */
/* SPAZA — Money tab                                                   */
/*   • Module C: Cash Flow & Delivery Float Estimator                  */
/*   • Module F: Value-Added Services (VAS) ledger — kept visually     */
/*     isolated from grocery cash                                      */
/*   • Module E: Overheads & Break-Even dashboard                      */
/* ------------------------------------------------------------------ */

import {
  breakEvenReport,
  floatReport,
  monthlyOverheads,
  sellingPrice,
  vasSplit,
  vasSummary,
} from "@/lib/engine";
import { fmtZAR, parseMoney, todayISO, uid } from "@/lib/money";
import { useShop } from "@/lib/store";
import {
  EXPENSE_CATEGORIES,
  VAS_META,
  type Expense,
  type ExpenseCategory,
  type VasTxn,
  type VasType,
} from "@/lib/types";
import {
  Banknote,
  Landmark,
  Minus,
  Plus,
  Receipt,
  Smartphone,
  Trash2,
  Truck,
  X,
  Zap,
} from "lucide-react";
import { useState } from "react";
import { Bar, Btn, Card, Empty, Field, NumInput, SectionHead, Seg, Select, Sticker, TextInput } from "./ui";

/* ================================================================ */
/* Module C — Delivery Float                                         */
/* ================================================================ */

function FloatSeg() {
  const { state, dispatch } = useShop();
  const [adding, setAdding] = useState(false);
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState("20");
  const [days, setDays] = useState("6");

  const report = floatReport(state.deliveries, state.products);
  const used = new Set(state.deliveries.map((d) => d.productId));
  const available = state.products.filter((p) => !used.has(p.id));

  const bump = (id: string, field: "qtyPerDay" | "daysPerWeek", delta: number) => {
    const line = state.deliveries.find((d) => d.id === id);
    if (!line) return;
    const next = Math.max(
      field === "daysPerWeek" ? 1 : 0,
      (line[field] ?? 0) + delta
    );
    dispatch({
      type: "upsert",
      collection: "deliveries",
      item: { ...line, [field]: field === "daysPerWeek" ? Math.min(7, next) : next },
    });
  };

  return (
    <div className="space-y-4">
      <p className="text-[11px] leading-relaxed font-semibold text-ink/55">
        Set the drop volume for each recurring delivery. The app multiplies it by the
        <em> live wholesale cost</em> from your stock list — so when the wholesale matrix
        moves, this float moves with it.
      </p>

      {report.lines.length > 0 && (
        <div className="space-y-2">
          {report.lines.map(({ line, product, unitCost, weeklyUnits, weeklyCost }) => (
            <Card key={line.id} className="p-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="truncate text-sm font-extrabold">
                    {product?.name ?? "Unknown product"}
                  </div>
                  <div className="text-[10px] font-bold text-ink/50">
                    {fmtZAR(unitCost)}/unit · supplier {product?.supplier || "—"}
                  </div>
                </div>
                <button
                  aria-label="Remove line"
                  onClick={() => dispatch({ type: "remove", collection: "deliveries", id: line.id })}
                  className="cursor-pointer text-ink/25 hover:text-brand-red"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {(
                  [
                    { label: "Units / day", field: "qtyPerDay", value: line.qtyPerDay },
                    { label: "Days / week", field: "daysPerWeek", value: line.daysPerWeek },
                  ] as const
                ).map(({ label, field, value }) => (
                  <div key={field} className="rounded-lg border-2 border-ink/15 bg-white p-2">
                    <div className="text-center text-[9px] font-extrabold uppercase tracking-wide text-ink/50">
                      {label}
                    </div>
                    <div className="mt-1 flex items-center justify-center gap-1.5">
                      <button
                        aria-label={`decrease ${label}`}
                        onClick={() => bump(line.id, field, -1)}
                        className="flex size-7 cursor-pointer items-center justify-center rounded-md border-2 border-ink bg-white shadow-hard-xs active:translate-y-[1px] active:shadow-none"
                      >
                        <Minus className="size-3.5" strokeWidth={3} />
                      </button>
                      <span className="min-w-8 text-center font-display text-lg tabular-nums">{value}</span>
                      <button
                        aria-label={`increase ${label}`}
                        onClick={() => bump(line.id, field, 1)}
                        className="flex size-7 cursor-pointer items-center justify-center rounded-md border-2 border-ink bg-gold shadow-hard-xs active:translate-y-[1px] active:shadow-none"
                      >
                        <Plus className="size-3.5" strokeWidth={3} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-2 flex items-center justify-between rounded-lg border-2 border-ink bg-paper px-2.5 py-1.5">
                <span className="text-[10px] font-extrabold uppercase tracking-wide text-ink/60">
                  {weeklyUnits} units a week
                </span>
                <span className="font-display text-lg tabular-nums">{fmtZAR(weeklyCost)}</span>
              </div>
            </Card>
          ))}
        </div>
      )}

      {adding ? (
        <Card className="space-y-3 p-3">
          <Field label="Delivery item">
            <Select value={productId} onChange={(e) => setProductId(e.target.value)}>
              <option value="">Choose from stock list…</option>
              {available.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} — {fmtZAR(p.costPrice)}
                </option>
              ))}
            </Select>
          </Field>
          <div className="grid grid-cols-2 gap-2.5">
            <Field label="Expected units per day">
              <NumInput value={qty} onChange={(e) => setQty(e.target.value)} />
            </Field>
            <Field label="Delivery days per week">
              <NumInput value={days} onChange={(e) => setDays(e.target.value)} />
            </Field>
          </div>
          <div className="flex gap-2">
            <Btn
              variant="green"
              className="flex-1"
              disabled={!productId}
              onClick={() => {
                dispatch({
                  type: "upsert",
                  collection: "deliveries",
                  item: {
                    id: uid(),
                    productId,
                    qtyPerDay: Math.max(0, Math.round(parseMoney(qty))),
                    daysPerWeek: Math.min(7, Math.max(1, Math.round(parseMoney(days)))),
                  },
                });
                setAdding(false);
                setProductId("");
              }}
            >
              Add delivery
            </Btn>
            <Btn variant="outline" icon={X} onClick={() => setAdding(false)}>Cancel</Btn>
          </div>
        </Card>
      ) : (
        available.length > 0 && (
          <Btn variant="outline" icon={Plus} className="w-full" onClick={() => setAdding(true)}>
            Add a delivery line
          </Btn>
        )
      )}

      {/* the float number */}
      <Card tone="gold" className="p-4">
        <Sticker tone="ink" rotate={false}>
          <Truck className="size-3" /> Weekly delivery cash float required
        </Sticker>
        <div className="mt-2 font-display text-[40px] leading-none tracking-tight tabular-nums">
          {fmtZAR(report.totalWeekly)}
        </div>
        <p className="mt-1.5 text-[11px] leading-snug font-bold text-ink/70">
          Keep this much physical cash in the truck envelope so the bread, milk and egg
          deliveries never bounce — roughly {fmtZAR(report.totalWeekly / 6)} per trading day.
        </p>
        <div className="mt-3">
          <Bar pct={1} tone="ink" />
        </div>
      </Card>
    </div>
  );
}

/* ================================================================ */
/* Module F — VAS ledger (digital float, visually isolated)          */
/* ================================================================ */

function VasSeg() {
  const { state, dispatch } = useShop();
  const [type, setType] = useState<VasType>("electricity");
  const [amount, setAmount] = useState("");
  const [reference, setReference] = useState("");
  const sum = vasSummary(state.vasTxns);
  const split = vasSplit(parseMoney(amount), VAS_META[type].defaultPct);

  const txns = [...state.vasTxns].sort((a, b) => (a.date < b.date ? 1 : -1));

  const logSale = () => {
    const amt = parseMoney(amount);
    if (amt <= 0) return;
    const t: VasTxn = {
      id: uid(),
      date: todayISO(),
      type,
      amount: amt,
      commissionPct: VAS_META[type].defaultPct,
      reference: reference.trim() || undefined,
    };
    dispatch({ type: "upsert", collection: "vasTxns", item: t });
    setAmount("");
    setReference("");
  };

  return (
    <div className="space-y-4">
      {/* isolation notice */}
      <Card tone="ink" className="p-3.5">
        <div className="flex items-start gap-2.5">
          <Smartphone className="mt-0.5 size-5 shrink-0 text-brand-sky" />
          <div>
            <div className="text-xs font-extrabold uppercase tracking-wider text-gold">
              Digital float — kept separate
            </div>
            <p className="mt-1 text-[11px] leading-relaxed text-paper/70">
              Airtime, electricity and bill-pay money lives in its own envelope. It is
              never mixed with grocery cash on this page or in your totals.
            </p>
          </div>
        </div>
      </Card>

      {/* summary */}
      <div className="grid grid-cols-3 gap-2">
        <Card className="p-2.5 text-center">
          <div className="text-[9px] font-extrabold uppercase tracking-wide text-ink/50">Vended</div>
          <div className="mt-0.5 font-display text-lg tabular-nums">{fmtZAR(sum.sold)}</div>
        </Card>
        <Card className="border-brand-green bg-green-50 p-2.5 text-center">
          <div className="text-[9px] font-extrabold uppercase tracking-wide text-brand-green">Your profit</div>
          <div className="mt-0.5 font-display text-lg text-brand-green tabular-nums">{fmtZAR(sum.commission)}</div>
        </Card>
        <Card className="p-2.5 text-center">
          <div className="text-[9px] font-extrabold uppercase tracking-wide text-ink/50">Remit to vendor</div>
          <div className="mt-0.5 font-display text-lg tabular-nums">{fmtZAR(sum.remit)}</div>
        </Card>
      </div>

      {/* new sale */}
      <Card className="space-y-3 p-3">
        <div className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-ink/50">
          Log a VAS sale
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          {(Object.keys(VAS_META) as VasType[]).map((t) => {
            const active = type === t;
            return (
              <button
                key={t}
                onClick={() => setType(t)}
                className={`cursor-pointer rounded-lg border-2 px-1.5 py-2 text-center transition-colors ${
                  active ? "border-ink bg-gold shadow-hard-xs" : "border-ink/25 bg-white"
                }`}
              >
                <div className="text-[9px] leading-tight font-extrabold uppercase tracking-wide">
                  {VAS_META[t].label}
                </div>
                <div className={`mt-0.5 text-[10px] font-extrabold ${active ? "text-brand-red" : "text-ink/45"}`}>
                  {VAS_META[t].defaultPct}% comm
                </div>
              </button>
            );
          })}
        </div>
        <div className="grid grid-cols-2 gap-2.5">
          <Field label="Vend amount (R)">
            <NumInput value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0,00" />
          </Field>
          <Field label="Reference (optional)">
            <TextInput value={reference} onChange={(e) => setReference(e.target.value)} placeholder={VAS_META[type].blurb} />
          </Field>
        </div>
        {parseMoney(amount) > 0 && (
          <div className="flex items-center justify-between rounded-lg border-2 border-brand-green bg-green-50 px-2.5 py-1.5 text-[11px] font-extrabold">
            <span className="text-brand-green">
              Keep {fmtZAR(split.commission)} ({VAS_META[type].defaultPct}%)
            </span>
            <span className="text-ink/60">remit {fmtZAR(split.remit)}</span>
          </div>
        )}
        <Btn variant="green" icon={Zap} className="w-full" onClick={logSale} disabled={parseMoney(amount) <= 0}>
          Log {VAS_META[type].label} sale
        </Btn>
      </Card>

      {/* ledger */}
      <div>
        <SectionHead kicker="Digital ledger" title={`VAS transactions (${sum.count})`} />
        {txns.length === 0 ? (
          <Empty icon={Smartphone} title="No VAS sales yet" body="Log electricity, airtime or bill payments to watch commission build up." />
        ) : (
          <div className="max-h-72 space-y-1.5 overflow-y-auto pr-1">
            {txns.map((t) => {
              const s = vasSplit(t.amount, t.commissionPct);
              return (
                <div key={t.id} className="flex items-center gap-2 rounded-lg border-2 border-ink/15 bg-white px-2.5 py-2">
                  <span className="flex size-8 shrink-0 items-center justify-center rounded-md border-2 border-ink bg-brand-blue text-white">
                    <Zap className="size-4" strokeWidth={2.6} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12px] font-extrabold">{VAS_META[t.type].label}</div>
                    <div className="truncate text-[9px] font-semibold text-ink/45">
                      {t.date}{t.reference ? ` · ${t.reference}` : ""}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[13px] font-extrabold tabular-nums">{fmtZAR(t.amount)}</div>
                    <div className="text-[9px] font-extrabold text-brand-green">+{fmtZAR(s.commission)}</div>
                  </div>
                  <button
                    aria-label="Delete transaction"
                    onClick={() => dispatch({ type: "remove", collection: "vasTxns", id: t.id })}
                    className="cursor-pointer text-ink/25 hover:text-brand-red"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ================================================================ */
/* Module E — Overheads + Break-even                                 */
/* ================================================================ */

const CATEGORY_TONE: Record<ExpenseCategory, string> = {
  Rent: "bg-brand-blue",
  Electricity: "bg-gold",
  Transport: "bg-brand-red",
  Data: "bg-brand-green",
  Other: "bg-ink",
};

function OverheadsSeg() {
  const { state, dispatch } = useShop();
  const [adding, setAdding] = useState(false);
  const [category, setCategory] = useState<ExpenseCategory>("Rent");
  const [label, setLabel] = useState("");
  const [amount, setAmount] = useState("");

  const total = monthlyOverheads(state.expenses);
  const be = breakEvenReport(state.expenses, state.products);

  const addExpense = () => {
    const amt = parseMoney(amount);
    if (amt <= 0) return;
    const e: Expense = {
      id: uid(),
      category,
      label: label.trim() || EXPENSE_CATEGORIES.find((c) => c.value === category)?.label || category,
      amount: amt,
    };
    dispatch({ type: "upsert", collection: "expenses", item: e });
    setLabel("");
    setAmount("");
    setAdding(false);
  };

  return (
    <div className="space-y-4">
      <SectionHead kicker="Fixed monthly costs" title={`Overheads · ${fmtZAR(total)}/mo`} />

      {adding ? (
        <Card className="space-y-3 p-3">
          <Field label="Category">
            <Select value={category} onChange={(e) => setCategory(e.target.value as ExpenseCategory)}>
              {EXPENSE_CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label} — {c.hint}
                </option>
              ))}
            </Select>
          </Field>
          <div className="grid grid-cols-2 gap-2.5">
            <Field label="Label">
              <TextInput value={label} onChange={(e) => setLabel(e.target.value)} placeholder="e.g. Yard rent" />
            </Field>
            <Field label="Amount / month (R)">
              <NumInput value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0,00" />
            </Field>
          </div>
          <div className="flex gap-2">
            <Btn variant="green" className="flex-1" disabled={parseMoney(amount) <= 0} onClick={addExpense}>
              Add overhead
            </Btn>
            <Btn variant="outline" icon={X} onClick={() => setAdding(false)}>Cancel</Btn>
          </div>
        </Card>
      ) : (
        <Btn variant="outline" icon={Plus} className="w-full" onClick={() => setAdding(true)}>
          Add a monthly cost
        </Btn>
      )}

      {state.expenses.length === 0 ? (
        <Empty icon={Receipt} title="No overheads logged" body="Add rent, electricity tokens, petrol and data so the break-even engine can do its maths." />
      ) : (
        <div className="space-y-1.5">
          {state.expenses.map((e) => (
            <div key={e.id} className="flex items-center gap-2.5 rounded-lg border-2 border-ink/15 bg-white px-2.5 py-2">
              <span className={`size-3 shrink-0 rounded-sm border border-ink ${CATEGORY_TONE[e.category]}`} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[12px] font-extrabold">{e.label}</div>
                <div className="text-[9px] font-bold uppercase tracking-wide text-ink/45">
                  {EXPENSE_CATEGORIES.find((c) => c.value === e.category)?.label ?? e.category}
                </div>
              </div>
              <div className="text-[13px] font-extrabold tabular-nums">{fmtZAR(e.amount)}</div>
              <button
                aria-label="Delete expense"
                onClick={() => dispatch({ type: "remove", collection: "expenses", id: e.id })}
                className="cursor-pointer text-ink/25 hover:text-brand-red"
              >
                <Trash2 className="size-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* break-even engine */}
      <Card tone="gold" className="relative overflow-hidden p-4">
        <div className="absolute -top-6 -right-6 size-28 rounded-full border-[10px] border-ink/10" />
        <Sticker tone="ink" rotate={false}>
          <Landmark className="size-3" /> Break-even engine
        </Sticker>

        {be.monthlyBreakEven !== null && be.dailyTarget !== null ? (
          <>
            <div className="mt-2 font-display text-[42px] leading-none tracking-tight tabular-nums sm:text-[46px]">
              {fmtZAR(be.dailyTarget)}
            </div>
            <p className="mt-1.5 max-w-[42ch] text-[11px] leading-snug font-bold text-ink/70 sm:text-xs">
              Daily sales needed to cover {fmtZAR(be.overheads)} monthly overheads at your
              average {be.avgMarginPct}% gross margin. Break-even month: {fmtZAR(be.monthlyBreakEven)}.
            </p>

            <div className="mt-3 grid grid-cols-2 gap-2.5">
              <div className="rounded-lg border-2 border-ink bg-white p-3 shadow-hard-xs">
                <div className="text-[9px] font-extrabold uppercase tracking-wide text-ink/55">
                  Monthly break-even
                </div>
                <div className="mt-1 font-display text-[26px] leading-none tabular-nums">
                  {fmtZAR(be.monthlyBreakEven)}
                </div>
                <div className="mt-1 text-[10px] font-bold text-ink/55">turnover to stand still</div>
              </div>
              <div className="rounded-lg border-2 border-ink bg-white p-3 shadow-hard-xs">
                <div className="text-[9px] font-extrabold uppercase tracking-wide text-ink/55">
                  Average margin
                </div>
                <div className="mt-1 font-display text-[26px] leading-none text-brand-green tabular-nums">
                  {be.avgMarginPct}%
                </div>
                <div className="mt-1 text-[10px] font-bold text-ink/55">
                  {be.marginBasis === "weighted"
                    ? "weighted by stock value"
                    : be.marginBasis === "simple"
                      ? "simple average basis"
                      : "default 25% basis"}
                </div>
              </div>
            </div>

            <div className="mt-3 rounded-lg border-2 border-ink bg-white/85 px-3 py-2 font-mono text-[10px] leading-relaxed text-ink/75 shadow-hard-xs">
              Break-even = overheads ÷ margin% → {fmtZAR(be.overheads)} ÷ {be.avgMarginPct}%
              <br />
              <span className="font-sans text-[10px] font-bold text-ink/50">
                margin {be.marginBasis === "weighted" ? "weighted by stock value at cost" : be.marginBasis === "simple" ? "simple average of product margins" : "assumed 25% — add stock to refine"}
              </span>
            </div>
          </>
        ) : (
          <div className="mt-3 rounded-lg border-2 border-ink bg-white/85 p-3 shadow-hard-xs">
            <p className="text-[11px] font-bold text-ink/70">
              Add stock with real margins to compute the break-even point.
            </p>
          </div>
        )}

        <p className="mt-3 text-[10px] leading-relaxed font-bold text-ink/65 sm:text-[11px]">
          Lower the target by trimming overheads or raising margins — the wholesale matrix
          in the Stock tab is where margin improvement starts.
        </p>
      </Card>
    </div>
  );
}

/* ================================================================ */
/* Pane                                                              */
/* ================================================================ */

type MoneySeg = "float" | "vas" | "overheads";

export function MoneyPane() {
  const [seg, setSeg] = useState<MoneySeg>("float");
  return (
    <div className="space-y-4">
      <div>
        <div className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-brand-red">
          Modules C · E · F
        </div>
        <h1 className="font-display text-3xl tracking-tight">Money Desk</h1>
        <p className="mt-0.5 text-xs font-semibold text-ink/55">
          Float for the trucks, the digital VAS envelope, and the number that keeps the
          doors open.
        </p>
      </div>

      <Seg<MoneySeg>
        value={seg}
        onChange={setSeg}
        options={[
          { value: "float", label: "Truck float", icon: Truck },
          { value: "vas", label: "VAS", icon: Zap },
          { value: "overheads", label: "Break-even", icon: Banknote },
        ]}
      />

      {seg === "float" && <FloatSeg />}
      {seg === "vas" && <VasSeg />}
      {seg === "overheads" && <OverheadsSeg />}
    </div>
  );
}
