"use client";

/* ------------------------------------------------------------------ */
/* SPAZA — Compliance Hub                                              */
/* Interactive onboarding checklist: CIPC, SARS, municipal trading     */
/* permit/zoning and the Department of Health COA under Regulation     */
/* R638. Progress is persisted with the rest of the shop state.        */
/* ------------------------------------------------------------------ */

import { useShop } from "@/lib/store";
import { COMPLIANCE_SECTIONS, type ComplianceSection } from "@/lib/types";
import {
  BadgeCheck,
  Building2,
  Check,
  ChevronDown,
  FileText,
  Landmark,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react";
import { useState } from "react";
import { Bar, Card, SectionHead, Sticker } from "./ui";

const SECTION_STYLE: Record<
  string,
  { icon: LucideIcon; chip: "blue" | "green" | "gold" | "red"; dot: string }
> = {
  cipc: { icon: Building2, chip: "blue", dot: "bg-brand-blue" },
  sars: { icon: Landmark, chip: "green", dot: "bg-brand-green" },
  muni: { icon: FileText, chip: "gold", dot: "bg-gold" },
  coa: { icon: ShieldCheck, chip: "red", dot: "bg-brand-red" },
};

/* ---------------- progress ring ---------------- */

function Ring({ pct }: { pct: number }) {
  const R = 52;
  const C = 2 * Math.PI * R;
  return (
    <div className="relative size-32">
      <svg viewBox="0 0 120 120" className="size-32 -rotate-90">
        <circle cx="60" cy="60" r={R} fill="none" stroke="var(--color-ink)" strokeWidth="4" opacity="0.12" />
        <circle
          cx="60"
          cy="60"
          r={R}
          fill="none"
          stroke="var(--color-brand-green)"
          strokeWidth="11"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - pct)}
          className="transition-all duration-500"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-3xl tabular-nums">{Math.round(pct * 100)}%</span>
        <span className="text-[8px] font-extrabold uppercase tracking-[0.18em] text-ink/55">
          licensed &amp; legal
        </span>
      </div>
    </div>
  );
}

/* ---------------- one section ---------------- */

function Section({ section, done }: { section: ComplianceSection; done: Record<string, boolean> }) {
  const { dispatch } = useShop();
  const [open, setOpen] = useState(section.id === "coa");
  const style = SECTION_STYLE[section.id];
  const Icon = style.icon;
  const completed = section.steps.filter((s) => done[s.id]).length;
  const pct = completed / section.steps.length;
  const full = pct >= 1;

  return (
    <Card className={full ? "bg-green-50" : ""}>
      <button onClick={() => setOpen((o) => !o)} className="flex w-full cursor-pointer items-start gap-3 p-3 text-left">
        <span className={`flex size-10 shrink-0 items-center justify-center rounded-lg border-2 border-ink ${style.dot} ${section.id === "muni" ? "text-ink" : "text-white"}`}>
          <Icon className="size-5" strokeWidth={2.4} />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <Sticker tone={full ? "green" : style.chip} rotate={false}>
              {section.code} · {completed}/{section.steps.length}
            </Sticker>
            {full && (
              <Sticker tone="ink" rotate={false}>
                <BadgeCheck className="size-2.5" /> done
              </Sticker>
            )}
          </div>
          <div className="mt-1 text-[15px] leading-tight font-extrabold">{section.title}</div>
          <div className="text-[10px] font-bold text-ink/50">{section.authority}</div>
          <div className="mt-2">
            <Bar pct={pct} tone={full ? "green" : section.id === "cipc" ? "blue" : section.id === "sars" ? "green" : section.id === "muni" ? "gold" : "red"} />
          </div>
        </div>
        <ChevronDown className={`mt-1 size-4 shrink-0 text-ink/40 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="space-y-2 border-t-2 border-ink/10 px-3 py-3">
          <p className="text-[11px] leading-relaxed font-semibold text-ink/60">{section.summary}</p>
          <div className="space-y-1.5">
            {section.steps.map((step, i) => {
              const checked = !!done[step.id];
              return (
                <button
                  key={step.id}
                  onClick={() => dispatch({ type: "toggleCompliance", stepId: step.id })}
                  className={`flex w-full cursor-pointer items-start gap-2.5 rounded-lg border-2 p-2.5 text-left transition-colors ${
                    checked ? "border-brand-green bg-green-50" : "border-ink/15 bg-white hover:border-ink/40"
                  }`}
                >
                  <span
                    className={`mt-0.5 flex size-5 shrink-0 items-center justify-center rounded border-2 ${
                      checked ? "border-ink bg-brand-green text-white" : "border-ink bg-white"
                    }`}
                  >
                    {checked && <Check className="size-3.5" strokeWidth={4} />}
                  </span>
                  <span className="min-w-0">
                    <span className={`block text-[12px] font-extrabold ${checked ? "line-through opacity-60" : ""}`}>
                      {i + 1}. {step.title}
                    </span>
                    <span className="mt-0.5 block text-[10.5px] leading-snug font-semibold text-ink/55">
                      {step.detail}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </Card>
  );
}

/* ---------------- pane ---------------- */

export function CompliancePane() {
  const { state } = useShop();
  const all = COMPLIANCE_SECTIONS.flatMap((s) => s.steps);
  const doneCount = all.filter((s) => state.compliance[s.id]).length;
  const pct = all.length ? doneCount / all.length : 0;

  return (
    <div className="space-y-4">
      <div>
        <div className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-brand-red">
          Compliance hub
        </div>
        <h1 className="font-display text-3xl tracking-tight">Papers &amp; Permits</h1>
        <p className="mt-0.5 text-xs font-semibold text-ink/55">
          Four authorities between you and a fully legal shop. Tick them off as you go —
          progress is saved on this phone and syncs up.
        </p>
      </div>

      <Card className="flex items-center gap-4 p-4">
        <Ring pct={pct} />
        <div className="min-w-0">
          <div className="font-display text-xl leading-tight">
            {pct >= 1 ? "Fully legit. Sharp sharp." : `${doneCount} of ${all.length} steps done`}
          </div>
          <p className="mt-1 text-[11px] leading-snug font-semibold text-ink/55">
            {pct >= 1
              ? "Frame the certificates, keep the fridge log going, and trade with confidence."
              : "Each tick moves you closer to inspection-proof trading. Start with whichever department is open today."}
          </p>
        </div>
      </Card>

      <SectionHead kicker="The paper trail" title="Four departments, four checklists" />

      <div className="space-y-2.5">
        {COMPLIANCE_SECTIONS.map((s) => (
          <Section key={s.id} section={s} done={state.compliance} />
        ))}
      </div>

      <Card tone="paper" className="p-3">
        <p className="text-[10.5px] leading-relaxed font-semibold text-ink/60">
          Official channels: CIPC eServices (eservices.cipc.co.za) · SARS eFiling
          (sarsefiling.co.za) · your municipal licensing &amp; town-planning offices · the
          Environmental Health office for the COA under Regulation R638. This checklist is
          a guide, not legal advice — municipal rules differ per area.
        </p>
      </Card>
    </div>
  );
}
