"use client";

/* ------------------------------------------------------------------ */
/* SPAZA — Module A (Inventory Master List) + Module B (Wholesale      */
/* Price Comparison Matrix). The matrix MIN() pipes straight into      */
/* product cost prices through the store reducer.                      */
/* ------------------------------------------------------------------ */

import {
  bestWholesalePrice,
  effectiveMarginPct,
  isReorder,
  retailFromMargin,
  sellingPrice,
  stockValueAtCost,
  weightedAvgMargin,
  wholesalerName,
} from "@/lib/engine";
import { fmtZAR, parseMoney, r2, uid } from "@/lib/money";
import { useShop } from "@/lib/store";
import type { Product, WholesalerRow } from "@/lib/types";
import {
  ArrowRight,
  ChevronDown,
  Factory,
  Link2,
  Minus,
  Package,
  Pencil,
  Plus,
  Scale,
  Trash2,
  X,
} from "lucide-react";
import { useState } from "react";
import { Btn, Card, Empty, Field, NumInput, SectionHead, Seg, Sticker, TextInput } from "./ui";

/* ---------------------------------------------------------------- */
/* shared bits                                                       */
/* ---------------------------------------------------------------- */

function FormulaBanner() {
  return (
    <div className="flex items-center gap-2.5 rounded-lg border-2 border-dashed border-ink/40 bg-white/60 px-3 py-2">
      <Scale className="size-4 shrink-0 text-ink/50" />
      <p className="text-[11px] leading-snug font-bold text-ink/65">
        Pricing engine:{" "}
        <span className="rounded bg-ink px-1 py-0.5 font-mono text-[10px] text-gold">
          Retail = Cost ÷ (1 − Margin%)
        </span>{" "}
        Cheapest wholesaler price pipes itself in as Cost.
      </p>
    </div>
  );
}

function q(v: number | null | undefined): string {
  return v == null ? "" : String(v);
}

/* ---------------------------------------------------------------- */
/* Add product form                                                  */
/* ---------------------------------------------------------------- */

function ProductForm({ onDone, existing }: { onDone: () => void; existing?: Product }) {
  const { dispatch } = useShop();
  const [name, setName] = useState(existing?.name ?? "");
  const [supplier, setSupplier] = useState(existing?.supplier ?? "");
  const [cost, setCost] = useState(q(existing?.costPrice));
  const [margin, setMargin] = useState(q(existing ? existing.marginPct : 25));
  const [stock, setStock] = useState(q(existing?.stock ?? 0));
  const [reorder, setReorder] = useState(q(existing?.reorderLevel ?? 5));
  const [override, setOverride] = useState(q(existing?.overridePrice));
  const [category, setCategory] = useState(existing?.category ?? "Staples");

  const calc = retailFromMargin(parseMoney(cost), parseMoney(margin || "0"));

  const save = () => {
    if (!name.trim()) return;
    const p: Product = {
      id: existing?.id ?? uid(),
      name: name.trim(),
      category: category.trim() || "General",
      supplier: supplier.trim(),
      costPrice: parseMoney(cost),
      marginPct: parseMoney(margin || "0"),
      overridePrice: override.trim() ? parseMoney(override) : null,
      stock: Math.max(0, Math.round(parseMoney(stock || "0"))),
      reorderLevel: Math.max(0, Math.round(parseMoney(reorder || "0"))),
    };
    dispatch({ type: "upsert", collection: "products", item: p });
    if (!existing) {
      // auto-create a wholesale matrix row so the interlink is live from day one
      const row: WholesalerRow = {
        id: uid(),
        productId: p.id,
        costA: p.costPrice || null,
        costB: null,
        costC: null,
        autoSync: true,
      };
      dispatch({ type: "upsert", collection: "wholesalers", item: row });
    }
    onDone();
  };

  return (
    <Card className="space-y-3 p-3">
      <div className="grid grid-cols-2 gap-2.5">
        <div className="col-span-2">
          <Field label="Product name">
            <TextInput value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Maize Meal 10kg" />
          </Field>
        </div>
        <Field label="Category">
          <TextInput value={category} onChange={(e) => setCategory(e.target.value)} placeholder="Staples" />
        </Field>
        <Field label="Supplier name">
          <TextInput value={supplier} onChange={(e) => setSupplier(e.target.value)} placeholder="Bread truck" />
        </Field>
        <Field label="Wholesale cost (R)">
          <NumInput value={cost} onChange={(e) => setCost(e.target.value)} placeholder="0,00" />
        </Field>
        <Field label="Target margin (%)">
          <NumInput value={margin} onChange={(e) => setMargin(e.target.value)} placeholder="25" />
        </Field>
        <Field label="Stock on hand">
          <NumInput value={stock} onChange={(e) => setStock(e.target.value)} placeholder="0" />
        </Field>
        <Field label="Min reorder level">
          <NumInput value={reorder} onChange={(e) => setReorder(e.target.value)} placeholder="5" />
        </Field>
        <div className="col-span-2">
          <Field label="Override selling price (R) — optional" hint="Leave blank to sell at the calculated retail price.">
            <NumInput value={override} onChange={(e) => setOverride(e.target.value)} placeholder={fmtZAR(calc)} />
          </Field>
        </div>
      </div>
      <div className="flex items-center justify-between gap-2 rounded-lg border-2 border-ink bg-paper px-3 py-2">
        <span className="text-[10px] font-extrabold uppercase tracking-wider text-ink/60">
          Calculated retail
        </span>
        <span className="font-display text-xl tabular-nums">{fmtZAR(calc)}</span>
      </div>
      <div className="flex gap-2">
        <Btn variant="green" className="flex-1" onClick={save} disabled={!name.trim()}>
          {existing ? "Save product" : "Add to stock list"}
        </Btn>
        <Btn variant="outline" onClick={onDone} icon={X}>Cancel</Btn>
      </div>
    </Card>
  );
}

/* ---------------------------------------------------------------- */
/* One product card                                                  */
/* ---------------------------------------------------------------- */

function ProductCard({ p }: { p: Product }) {
  const { state, dispatch } = useShop();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(false);

  const row = state.wholesalers.find((w) => w.productId === p.id);
  const best = row ? bestWholesalePrice(row) : null;
  const piped = !!(row?.autoSync && best);
  const low = isReorder(p);
  const sell = sellingPrice(p);
  const calc = retailFromMargin(p.costPrice, p.marginPct);
  const eff = effectiveMarginPct(p);

  const bump = (d: number) =>
    dispatch({
      type: "upsert",
      collection: "products",
      item: { ...p, stock: Math.max(0, p.stock + d) },
    });

  if (editing) {
    return <ProductForm existing={p} onDone={() => setEditing(false)} />;
  }

  return (
    <Card tone={low ? "paper" : "white"} className={low ? "bg-red-50" : ""}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full cursor-pointer items-start justify-between gap-2 p-3 text-left"
      >
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            {low && <Sticker tone="red" rotate={false}>Reorder alert</Sticker>}
            {piped && best && (
              <Sticker tone="blue" rotate={false}>
                <Link2 className="size-2.5" /> auto · {wholesalerName(best.source)}
              </Sticker>
            )}
            {p.overridePrice != null && <Sticker tone="ink" rotate={false}>manual price</Sticker>}
          </div>
          <div className="mt-1 truncate text-[15px] font-extrabold">{p.name}</div>
          <div className="text-[11px] font-semibold text-ink/55">
            {p.category} · {p.supplier || "no supplier"}
          </div>
        </div>
        <div className="shrink-0 text-right">
          <div className="font-display text-2xl leading-none tabular-nums">{fmtZAR(sell)}</div>
          <div className="mt-0.5 text-[10px] font-bold text-ink/50">selling price</div>
        </div>
      </button>

      {/* stock strip */}
      <div className="flex items-center justify-between gap-2 border-t-2 border-dashed border-ink/20 px-3 py-2">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => bump(-1)}
            aria-label="Remove one"
            className="flex size-8 cursor-pointer items-center justify-center rounded-md border-2 border-ink bg-white shadow-hard-xs active:translate-y-[1px] active:shadow-none"
          >
            <Minus className="size-4" strokeWidth={3} />
          </button>
          <span className={`min-w-12 text-center font-display text-xl tabular-nums ${low ? "text-brand-red" : ""}`}>
            {p.stock}
          </span>
          <button
            onClick={() => bump(1)}
            aria-label="Add one"
            className="flex size-8 cursor-pointer items-center justify-center rounded-md border-2 border-ink bg-gold shadow-hard-xs active:translate-y-[1px] active:shadow-none"
          >
            <Plus className="size-4" strokeWidth={3} />
          </button>
          <span className="ml-1 text-[10px] font-bold uppercase text-ink/50">
            on hand · min {p.reorderLevel}
          </span>
        </div>
        <ChevronDown
          className={`size-4 text-ink/40 transition-transform ${open ? "rotate-180" : ""}`}
        />
      </div>

      {open && (
        <div className="space-y-3 border-t-2 border-ink/10 px-3 py-3">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="rounded-lg border-2 border-ink/15 bg-white p-2">
              <div className="text-[9px] font-extrabold uppercase tracking-wide text-ink/50">Cost</div>
              <div className="mt-0.5 text-sm font-extrabold tabular-nums">{fmtZAR(p.costPrice)}</div>
              {piped && <div className="text-[9px] font-bold text-brand-blue">piped in</div>}
            </div>
            <div className="rounded-lg border-2 border-ink/15 bg-white p-2">
              <div className="text-[9px] font-extrabold uppercase tracking-wide text-ink/50">Target margin</div>
              <div className="mt-0.5 text-sm font-extrabold tabular-nums">{r2(p.marginPct)}%</div>
              <div className="text-[9px] font-bold text-ink/40">actual {eff}%</div>
            </div>
            <div className="rounded-lg border-2 border-ink/15 bg-white p-2">
              <div className="text-[9px] font-extrabold uppercase tracking-wide text-ink/50">Calc retail</div>
              <div
                className={`mt-0.5 text-sm font-extrabold tabular-nums ${
                  p.overridePrice != null ? "line-through opacity-50" : ""
                }`}
              >
                {fmtZAR(calc)}
              </div>
              {p.overridePrice != null && <div className="text-[9px] font-bold text-brand-red">overridden</div>}
            </div>
          </div>
          <div className="flex gap-2">
            <Btn variant="outline" size="sm" icon={Pencil} className="flex-1" onClick={() => setEditing(true)}>
              Edit details
            </Btn>
            <Btn
              variant="red"
              size="sm"
              icon={Trash2}
              onClick={() => dispatch({ type: "deleteProduct", id: p.id })}
            >
              Delete
            </Btn>
          </div>
        </div>
      )}
    </Card>
  );
}

/* ---------------------------------------------------------------- */
/* Wholesale matrix                                                  */
/* ---------------------------------------------------------------- */

function CostCell({
  value,
  best,
  onCommit,
}: {
  value: number | null;
  best: boolean;
  onCommit: (v: number | null) => void;
}) {
  return (
    <div className="relative">
      <input
        key={value ?? "empty"}
        defaultValue={value == null ? "" : String(value)}
        inputMode="decimal"
        placeholder="—"
        onBlur={(e) => {
          const raw = e.target.value.trim();
          onCommit(raw === "" ? null : parseMoney(raw));
        }}
        onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
        className={`w-full rounded-md border-2 bg-white px-1.5 py-2 text-center text-[13px] font-extrabold tabular-nums outline-none focus:shadow-hard-xs ${
          best ? "border-brand-green bg-green-50 text-brand-green" : "border-ink/25"
        }`}
      />
      {best && (
        <span className="absolute -top-2 left-1/2 -translate-x-1/2 rounded border border-ink bg-brand-green px-1 text-[8px] font-extrabold text-white">
          BEST
        </span>
      )}
    </div>
  );
}

function MatrixRow({ row }: { row: WholesalerRow }) {
  const { state, dispatch } = useShop();
  const product = state.products.find((p) => p.id === row.productId);
  const best = bestWholesalePrice(row);
  if (!product) return null;
  const patch = (p: Partial<WholesalerRow>) =>
    dispatch({ type: "upsert", collection: "wholesalers", item: { ...row, ...p } });

  return (
    <Card className="p-3">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate text-sm font-extrabold">{product.name}</div>
          <div className="text-[10px] font-bold text-ink/50">
            current cost {fmtZAR(product.costPrice)}
          </div>
        </div>
        {best ? (
          <Sticker tone="green" rotate={false}>
            {wholesalerName(best.source)} wins
          </Sticker>
        ) : (
          <Sticker tone="paper" rotate={false}>no prices yet</Sticker>
        )}
      </div>

      <div className="mt-2.5 grid grid-cols-3 gap-2 pt-2">
        <CostCell value={row.costA} best={best?.source === 0} onCommit={(v) => patch({ costA: v })} />
        <CostCell value={row.costB} best={best?.source === 1} onCommit={(v) => patch({ costB: v })} />
        <CostCell value={row.costC} best={best?.source === 2} onCommit={(v) => patch({ costC: v })} />
      </div>

      <div className="mt-2 flex items-center justify-between gap-2">
        <button
          onClick={() => patch({ autoSync: !row.autoSync })}
          className="flex cursor-pointer items-center gap-1.5"
        >
          <span
            className={`relative h-5 w-9 rounded-full border-2 border-ink transition-colors ${
              row.autoSync ? "bg-brand-green" : "bg-white"
            }`}
          >
            <span
              className={`absolute top-0.5 size-3 rounded-full border border-ink bg-white transition-all ${
                row.autoSync ? "left-[18px]" : "left-0.5"
              }`}
            />
          </span>
          <span className="text-[10px] font-extrabold uppercase tracking-wide text-ink/60">
            {row.autoSync ? "Auto-pipe ON" : "Auto-pipe off"}
          </span>
        </button>
        {best && !row.autoSync && (
          <Btn
            size="sm"
            variant="green"
            onClick={() =>
              dispatch({
                type: "upsert",
                collection: "products",
                item: { ...product, costPrice: best.value },
              })
            }
          >
            Use {fmtZAR(best.value)} <ArrowRight className="size-3.5" />
          </Btn>
        )}
        {best && row.autoSync && (
          <span className="text-[10px] font-bold text-brand-green">
            {fmtZAR(best.value)} → cost price
          </span>
        )}
      </div>
    </Card>
  );
}

/* ---------------------------------------------------------------- */
/* Main pane                                                         */
/* ---------------------------------------------------------------- */

type StockSeg = "list" | "matrix";

export function StockPane() {
  const { state } = useShop();
  const [seg, setSeg] = useState<StockSeg>("list");
  const [adding, setAdding] = useState(false);

  const value = stockValueAtCost(state.products);
  const margin = weightedAvgMargin(state.products);
  const lowCount = state.products.filter(isReorder).length;
  const rowed = new Set(state.wholesalers.map((w) => w.productId));

  return (
    <div className="space-y-4">
      <div>
        <div className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-brand-red">
          Module A + B
        </div>
        <h1 className="font-display text-3xl tracking-tight">Stock &amp; Prices</h1>
        <p className="mt-0.5 text-xs font-semibold text-ink/55">
          {state.products.length} lines · worth {fmtZAR(value)} at cost · avg margin{" "}
          {margin.pct}%{lowCount > 0 ? ` · ${lowCount} to reorder` : ""}
        </p>
      </div>

      <Seg<StockSeg>
        value={seg}
        onChange={setSeg}
        options={[
          { value: "list", label: "Stock list", icon: Package },
          { value: "matrix", label: "Wholesale matrix", icon: Factory },
        ]}
      />

      <FormulaBanner />

      {seg === "list" ? (
        <>
          <SectionHead
            kicker="Pricing engine"
            title="Inventory master list"
            action={
              !adding ? (
                <Btn size="sm" icon={Plus} onClick={() => setAdding(true)}>
                  Add
                </Btn>
              ) : undefined
            }
          />
          {adding && <ProductForm onDone={() => setAdding(false)} />}
          {state.products.length === 0 ? (
            <Empty
              icon={Package}
              title="No stock lines yet"
              body="Add your first product — cost, target margin and stock level — and the engine prices it for you."
            />
          ) : (
            <div className="space-y-2.5">
              {[...state.products]
                .sort((a, b) => Number(isReorder(b)) - Number(isReorder(a)))
                .map((p) => (
                  <ProductCard key={p.id} p={p} />
                ))}
            </div>
          )}
        </>
      ) : (
        <>
          <SectionHead
            kicker="MIN() across suppliers"
            title="Wholesale price matrix"
          />
          <div className="grid grid-cols-3 gap-2 px-1 pb-0 text-center text-[9px] font-extrabold uppercase tracking-wide text-ink/50">
            <span>Makro (A)</span>
            <span>Boxer (B)</span>
            <span>Jumbo (C)</span>
          </div>
          {state.wholesalers.length === 0 ? (
            <Empty
              icon={Factory}
              title="Matrix is empty"
              body="Add products to the stock list and each one appears here for three-way supplier comparison."
            />
          ) : (
            <div className="space-y-2.5">
              {state.wholesalers.map((w) => (
                <MatrixRow key={w.id} row={w} />
              ))}
            </div>
          )}
          {state.products.some((p) => !rowed.has(p.id)) && (
            <p className="text-[11px] font-bold text-ink/55">
              Tip: items without a matrix row still use their manual cost price — add
              them in the stock list and a row is created automatically.
            </p>
          )}
        </>
      )}
    </div>
  );
}
