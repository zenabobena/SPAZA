"use client";

/* ------------------------------------------------------------------ */
/* SPAZA — application shell                                           */
/* Mobile-first frame + bottom tab bar; on desktop the phone column    */
/* sits inside a branded side-rail spread.                             */
/* ------------------------------------------------------------------ */

import { StoreProvider, useShop, type SyncStatus } from "@/lib/store";
import {
  Banknote,
  BookUser,
  Boxes,
  CloudOff,
  House,
  RefreshCw,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { CompliancePane } from "./CompliancePane";
import { CreditPane } from "./CreditPane";
import { HomePane } from "./HomePane";
import { MoneyPane } from "./MoneyPane";
import { StockPane } from "./StockPane";

export type Tab = "home" | "stock" | "credit" | "money" | "comply";

const TABS: { id: Tab; label: string; icon: LucideIcon }[] = [
  { id: "home", label: "Home", icon: House },
  { id: "stock", label: "Stock", icon: Boxes },
  { id: "credit", label: "Tab Book", icon: BookUser },
  { id: "money", label: "Money", icon: Banknote },
  { id: "comply", label: "Comply", icon: ShieldCheck },
];

/* ---------------- Logo: hand-drawn spaza storefront ---------------- */

export function Logo({ size = 34 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 44 44"
      fill="none"
      aria-hidden="true"
      className="shrink-0"
    >
      <rect width="44" height="44" rx="9" fill="var(--color-gold)" />
      <rect
        x="1.5"
        y="1.5"
        width="41"
        height="41"
        rx="7.5"
        stroke="var(--color-ink)"
        strokeWidth="3"
      />
      {/* storefront body */}
      <path d="M10 18h24v14h-24z" fill="var(--color-paper)" stroke="var(--color-ink)" strokeWidth="2.6" />
      {/* door */}
      <path d="M19 32v-8h6v8" fill="var(--color-brand-green)" stroke="var(--color-ink)" strokeWidth="2.4" />
      {/* awning */}
      <path
        d="M9 12h26l-2.2 5c-.4 1.6-2 2-3.1 2s-2.6-.8-3-2c-.4 1.2-1.9 2-3 2s-2.7-.8-3.1-2c-.4 1.2-1.9 2-3 2s-2.6-.8-3-2c-.4 1.2-1.9 2-3 2-1.1 0-2.7-.4-3.1-2L9 12Z"
        fill="var(--color-brand-red)"
        stroke="var(--color-ink)"
        strokeWidth="2.4"
      />
      {/* star */}
      <path
        d="M34.2 5.6l.95 2 2.17.28-1.6 1.5.4 2.15-1.92-1.05-1.92 1.05.4-2.15-1.6-1.5 2.17-.28.95-2Z"
        fill="var(--color-ink)"
      />
    </svg>
  );
}

/* ---------------- Sync badge ---------------- */

const SYNC_META: Record<
  SyncStatus,
  { label: string; dot: string; text: string; pulse?: boolean; spin?: boolean }
> = {
  boot: { label: "Connecting", dot: "bg-gold", text: "text-ink/60" },
  synced: { label: "Synced", dot: "bg-brand-green", text: "text-ink/70" },
  pending: { label: "Syncing", dot: "bg-gold", text: "text-ink/70", spin: true },
  offline: { label: "Offline · saved on device", dot: "bg-brand-red", text: "text-brand-red", pulse: true },
};

function SyncBadge() {
  const { sync, online } = useShop();
  const meta = SYNC_META[sync];
  const offline = sync === "offline" || !online;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border-2 border-ink px-2 py-1 text-[9px] font-extrabold uppercase tracking-[0.09em] shadow-hard-xs ${
        offline ? "bg-white" : "bg-paper"
      }`}
      title={
        offline
          ? "No signal / load shedding — everything you log is stored on this phone and syncs later."
          : "Your shop data is backed up."
      }
    >
      {meta.spin ? (
        <RefreshCw className="size-3 text-gold-deep" strokeWidth={3} />
      ) : offline ? (
        <CloudOff className="size-3 text-brand-red" strokeWidth={3} />
      ) : (
        <span className={`size-2 rounded-full border border-ink ${meta.dot}`} />
      )}
      <span className={meta.text}>{offline ? "Offline · saved" : meta.label}</span>
    </span>
  );
}

/* ---------------- Header ---------------- */

function Header() {
  const d = new Date();
  const dateStr = d.toLocaleDateString("en-ZA", {
    weekday: "short",
    day: "numeric",
    month: "short",
  });
  return (
    <header className="z-20 flex items-center gap-2 border-b-2 border-ink bg-paper px-3 py-2">
      {/* left: logo mark + wordmark, vertically centred together */}
      <div className="flex shrink-0 items-center gap-2">
        <Logo size={36} />
        <span className="font-display text-[36px] leading-none tracking-wide">SPAZA</span>
      </div>

      {/* centre: date — takes all remaining space, text centred */}
      <div className="min-w-0 flex-1 text-center text-[10px] font-extrabold uppercase tracking-[0.18em] text-ink/50">
        {dateStr}
      </div>

      {/* right: sync badge */}
      <div className="shrink-0">
        <SyncBadge />
      </div>
    </header>
  );
}

/* ---------------- Bottom tab bar ---------------- */

function BottomNav({ tab, setTab }: { tab: Tab; setTab: (t: Tab) => void }) {
  return (
    <nav className="z-20 border-t-2 border-ink bg-ink px-1.5 pt-1.5 pb-[calc(0.375rem+env(safe-area-inset-bottom))]">
      <div className="grid grid-cols-5 gap-1">
        {TABS.map(({ id, label, icon: Icon }) => {
          const active = tab === id;
          return (
            <button
              key={id}
              onClick={() => setTab(id)}
              aria-current={active ? "page" : undefined}
              className={`flex cursor-pointer flex-col items-center gap-0.5 rounded-lg py-1.5 transition-colors ${
                active ? "bg-gold text-ink" : "text-paper/55 hover:text-paper"
              }`}
            >
              <Icon className="size-5" strokeWidth={active ? 2.8 : 2.2} />
              <span className="text-[9px] font-extrabold uppercase tracking-[0.07em]">
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

/* ---------------- Desktop brand rail ---------------- */

function RailBullet({ n, title, body }: { n: string; title: string; body: string }) {
  return (
    <li className="flex gap-3">
      <span className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md border-2 border-gold bg-transparent font-display text-sm text-gold">
        {n}
      </span>
      <div>
        <div className="text-sm font-extrabold uppercase tracking-wide text-paper">{title}</div>
        <p className="mt-0.5 text-xs leading-relaxed text-paper/55">{body}</p>
      </div>
    </li>
  );
}

function BrandRail() {
  return (
    <aside className="hidden w-[380px] shrink-0 flex-col justify-between overflow-y-auto border-r-2 border-ink bg-ink p-8 text-paper lg:flex no-scrollbar">
      <div>
        <div className="flex items-center gap-3">
          <Logo size={52} />
          <div className="font-display text-4xl tracking-wide text-gold">SPAZA</div>
        </div>
        <h1 className="mt-8 font-display text-[44px] leading-[1.02] tracking-tight">
          RUN YOUR SHOP.
          <br />
          <span className="text-gold">COUNT YOUR CASH.</span>
          <br />
          PASS YOUR CHECKS.
        </h1>
        <p className="mt-5 max-w-[34ch] text-sm leading-relaxed text-paper/65">
          The offline-first business OS built for spaza owners. Price your stock,
          beat the wholesalers down, plan the bread truck float, run the tab book
          and stay inspection-ready — even when load shedding hits.
        </p>
        <ul className="mt-8 space-y-5">
          <RailBullet n="A" title="Smart pricing engine" body="Target margin converts wholesale cost to shelf price automatically. Override when you must." />
          <RailBullet n="B" title="Wholesale matrix" body="Three suppliers side by side. The cheapest price pipes itself into your cost price." />
          <RailBullet n="C" title="Tab book guardrails" body="Customer credit with hard limits. Breaches lock the tab until money comes back." />
          <RailBullet n="D" title="Break-even target" body="Overheads divided by your average margin gives the daily sales number to survive." />
        </ul>
      </div>
      <div className="mt-10 text-[10px] font-extrabold uppercase tracking-[0.25em]">
        <span className="inline-flex items-center gap-2 rounded-full border border-paper/25 px-3 py-1.5 text-paper/55">
          <span className="size-1.5 rounded-full bg-brand-green" />
          Offline-first · Works through load shedding
        </span>
      </div>
    </aside>
  );
}

function DecoColumn() {
  return (
    <div className="relative hidden flex-1 overflow-hidden lg:block" aria-hidden="true">
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="rotate-90 font-display text-[11vw] tracking-[0.08em] whitespace-nowrap text-transparent [-webkit-text-stroke:2px_var(--color-ink)] opacity-[0.13] select-none">
          SPAZA · OS · MZANSI · EDITION ·
        </span>
      </div>
    </div>
  );
}

/* ---------------- Splash ---------------- */

function Splash() {
  return (
    <div className="flex h-dvh flex-col items-center justify-center gap-5 bg-ink">
      <div className="animate-splash flex flex-col items-center gap-4">
        <Logo size={72} />
        <div className="font-display text-5xl tracking-wide text-gold">SPAZA</div>
        <div className="text-[10px] font-extrabold uppercase tracking-[0.3em] text-paper/60">
          Opening the shop…
        </div>
      </div>
    </div>
  );
}

/* ---------------- Shell ---------------- */

function Shell() {
  const [tab, setTab] = useState<Tab>("home");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);

  if (!mounted) return <Splash />;

  const panes: Record<Tab, ReactNode> = {
    home: <HomePane go={setTab} />,
    stock: <StockPane />,
    credit: <CreditPane />,
    money: <MoneyPane />,
    comply: <CompliancePane />,
  };

  return (
    <div className="flex h-dvh bg-paper lg:bg-paper-deep">
      <BrandRail />
      <div className="flex min-w-0 flex-1 flex-col border-ink bg-paper lg:max-w-[560px] lg:border-x-2">
        <Header />
        <main className="scroll-rail min-h-0 flex-1 overflow-y-auto overscroll-contain px-3 pt-4 pb-6">
          {panes[tab]}
        </main>
        <BottomNav tab={tab} setTab={setTab} />
      </div>
      <DecoColumn />
    </div>
  );
}

export function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
