/* ------------------------------------------------------------------ */
/* SPAZA — PostgreSQL schema (Drizzle ORM)                             */
/* One table per module. Client syncs whole-shop snapshots; server     */
/* stores them relationally so reports can be queried directly.        */
/* ------------------------------------------------------------------ */

import {
  boolean,
  doublePrecision,
  integer,
  pgTable,
  text,
  varchar,
} from "drizzle-orm/pg-core";

/** Module A — Smart Inventory Master List */
export const products = pgTable("spaza_products", {
  id: text("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  category: varchar("category", { length: 80 }).notNull().default("General"),
  costPrice: doublePrecision("cost_price").notNull().default(0),
  marginPct: doublePrecision("margin_pct").notNull().default(25),
  overridePrice: doublePrecision("override_price"),
  stock: integer("stock").notNull().default(0),
  reorderLevel: integer("reorder_level").notNull().default(5),
  supplier: varchar("supplier", { length: 160 }).notNull().default(""),
});

/** Module B — Wholesale Price Comparison Matrix */
export const wholesalerPrices = pgTable("spaza_wholesaler_prices", {
  id: text("id").primaryKey(),
  productId: text("product_id").notNull(),
  costA: doublePrecision("cost_a"),
  costB: doublePrecision("cost_b"),
  costC: doublePrecision("cost_c"),
  autoSync: boolean("auto_sync").notNull().default(true),
});

/** Module C — Delivery Float lines */
export const deliveryLines = pgTable("spaza_delivery_lines", {
  id: text("id").primaryKey(),
  productId: text("product_id").notNull(),
  qtyPerDay: integer("qty_per_day").notNull().default(0),
  daysPerWeek: integer("days_per_week").notNull().default(6),
});

/** Module D — Customer Tab Book */
export const customers = pgTable("spaza_customers", {
  id: text("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull().default(""),
  creditLimit: doublePrecision("credit_limit").notNull().default(200),
});

export const creditEntries = pgTable("spaza_credit_entries", {
  id: text("id").primaryKey(),
  customerId: text("customer_id").notNull(),
  date: varchar("date", { length: 10 }).notNull(),
  item: varchar("item", { length: 200 }).notNull().default(""),
  credit: doublePrecision("credit").notNull().default(0),
  payment: doublePrecision("payment").notNull().default(0),
});

/** Module E — Overheads */
export const expenses = pgTable("spaza_expenses", {
  id: text("id").primaryKey(),
  category: varchar("category", { length: 40 }).notNull().default("Other"),
  label: varchar("label", { length: 200 }).notNull().default(""),
  amount: doublePrecision("amount").notNull().default(0),
});

/** Module F — VAS Ledger */
export const vasTxns = pgTable("spaza_vas_txns", {
  id: text("id").primaryKey(),
  date: varchar("date", { length: 10 }).notNull(),
  type: varchar("type", { length: 20 }).notNull(),
  amount: doublePrecision("amount").notNull().default(0),
  commissionPct: doublePrecision("commission_pct").notNull().default(0),
  reference: varchar("reference", { length: 200 }),
});

/** Compliance Hub progress */
export const complianceChecks = pgTable("spaza_compliance_checks", {
  id: text("id").primaryKey(), // e.g. "coa.4"
  done: boolean("done").notNull().default(false),
});

/** Sync metadata (single row, id = "shop") */
export const shopMeta = pgTable("spaza_meta", {
  id: text("id").primaryKey(),
  updatedAt: varchar("updated_at", { length: 40 }).notNull(),
});
