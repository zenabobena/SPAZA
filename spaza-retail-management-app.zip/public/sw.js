/* SPAZA service worker — keeps the app shell alive through load shedding.
   Strategy:
   • page navigations: network-first, cached copy as fallback when offline
   • static chunks/icons: cache-first (immutable), network as fallback
   • everything else (incl. /api/state): network only — data lives in
     localStorage and syncs when the network returns                       */

const CACHE = "spaza-shell-v1";

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(caches.open(CACHE));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
      await self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // page loads → try network, fall back to cached shell when offline
  if (req.mode === "navigate") {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE);
        try {
          const fresh = await fetch(req);
          if (fresh.ok) cache.put("/", fresh.clone());
          return fresh;
        } catch {
          const cached = (await cache.match(req)) || (await cache.match("/"));
          if (cached) return cached;
          throw new Error("offline and no cached shell");
        }
      })()
    );
    return;
  }

  // build assets + icons are fingerprinted/immutable → cache-first
  if (url.pathname.startsWith("/_next/static") || url.pathname.startsWith("/icon")) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(CACHE);
        const hit = await cache.match(req);
        if (hit) return hit;
        const res = await fetch(req);
        if (res.ok) cache.put(req, res.clone());
        return res;
      })()
    );
  }
});
